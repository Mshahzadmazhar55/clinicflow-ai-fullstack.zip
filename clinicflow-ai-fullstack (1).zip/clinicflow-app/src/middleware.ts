import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";

// Tenant + auth edge. In production this checks the session/subdomain and
// guards app routes. In local/demo mode it passes through so the seeded
// clinic is usable without signing in.
export function middleware(_req: NextRequest) {
  return NextResponse.next();
}

export const config = {
  matcher: ["/((?!api/auth|_next/static|_next/image|favicon.ico|login).*)"],
};
