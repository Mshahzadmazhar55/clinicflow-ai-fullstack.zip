import { TrendingUp, Repeat, Star, Clock } from "lucide-react";
import { PageHeader } from "@/components/shared/page-header";
import { StatCard } from "@/components/shared/stat-card";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { AreaRevenue } from "@/components/charts/area-revenue";
import { BarAppointments } from "@/components/charts/bar-appointments";
import { LineRetention } from "@/components/charts/line-retention";
import { getAnalytics } from "@/server/queries";
import { formatIDR } from "@/lib/utils";

export const dynamic = "force-dynamic";

export default async function AnalyticsPage() {
  const { series, totalRevenue, practitioners } = await getAnalytics();
  const retention = series.map((s, i) => ({ week: `M${i + 1}`, returning: Math.round(s.appointments * 0.6) }));
  const maxRev = Math.max(1, ...practitioners.map((p) => p._count.appointments));
  return (
    <div className="space-y-6 animate-fade-in">
      <PageHeader title="Analytics" description="Performance across revenue, appointments and staff." />
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Total revenue (6mo)" value={formatIDR(totalRevenue / 100)} delta={24} icon={TrendingUp} />
        <StatCard label="Appointments" value={String(series.reduce((s, x) => s + x.appointments, 0))} delta={9} icon={Repeat} />
        <StatCard label="Avg. rating" value="4.8" delta={2} icon={Star} />
        <StatCard label="Avg. wait time" value="9 min" delta={-15} icon={Clock} />
      </div>
      <Tabs defaultValue="revenue">
        <TabsList><TabsTrigger value="revenue">Revenue</TabsTrigger><TabsTrigger value="appointments">Appointments</TabsTrigger><TabsTrigger value="retention">Retention</TabsTrigger></TabsList>
        <TabsContent value="revenue"><Card><CardHeader><CardTitle>Monthly revenue</CardTitle><CardDescription>In million IDR</CardDescription></CardHeader><CardContent><AreaRevenue data={series} /></CardContent></Card></TabsContent>
        <TabsContent value="appointments"><Card><CardHeader><CardTitle>Appointment volume</CardTitle><CardDescription>Per month</CardDescription></CardHeader><CardContent><BarAppointments data={series} /></CardContent></Card></TabsContent>
        <TabsContent value="retention"><Card><CardHeader><CardTitle>Returning patients</CardTitle><CardDescription>Estimated returning visits</CardDescription></CardHeader><CardContent><LineRetention data={retention} /></CardContent></Card></TabsContent>
      </Tabs>
      <Card>
        <CardHeader><CardTitle>Practitioner performance</CardTitle><CardDescription>Appointments handled</CardDescription></CardHeader>
        <CardContent className="space-y-3">
          {practitioners.map((p) => (
            <div key={p.id} className="flex items-center gap-4">
              <div className="w-28 truncate text-sm font-medium">{p.displayName}</div>
              <div className="flex-1"><div className="h-2 w-full overflow-hidden rounded-full bg-secondary"><div className="h-full rounded-full bg-primary" style={{ width: `${(p._count.appointments / maxRev) * 100}%` }} /></div></div>
              <div className="w-24 text-right text-sm tnum text-muted-foreground">{p._count.appointments} appts</div>
            </div>
          ))}
          {practitioners.length === 0 && <p className="py-6 text-center text-sm text-muted-foreground">No practitioners yet.</p>}
        </CardContent>
      </Card>
    </div>
  );
}
