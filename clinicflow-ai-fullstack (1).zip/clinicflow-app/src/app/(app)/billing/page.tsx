import { Check, Zap, TrendingUp, Receipt } from "lucide-react";
import { PageHeader } from "@/components/shared/page-header";
import { StatCard } from "@/components/shared/stat-card";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/components/ui/table";
import { getBilling, getPatientOptions } from "@/server/queries";
import { PLANS } from "@/lib/constants";
import { formatIDR, statusLabel, cn } from "@/lib/utils";
import { format } from "date-fns";
import { NewInvoiceButton, MarkPaidButton } from "./billing-client";

export const dynamic = "force-dynamic";
const statusTone = { PAID: "success", SENT: "default", OVERDUE: "destructive", DRAFT: "secondary", VOID: "secondary" } as const;

export default async function BillingPage() {
  const [{ sub, invoices, seats, outstanding }, patients] = await Promise.all([getBilling(), getPatientOptions()]);
  const tier = sub?.tier ?? "GROWTH";
  const usage = [
    { label: "WhatsApp messages", used: sub?.whatsappMsgUsed ?? 0, limit: sub?.whatsappMsgLimit ?? 1 },
    { label: "AI credits", used: sub?.aiCreditsUsed ?? 0, limit: sub?.aiCreditsLimit ?? 1 },
    { label: "Team seats", used: seats, limit: sub?.seatsLimit ?? 1 },
  ];
  const monthly = PLANS.find((p) => p.tier === tier)?.priceCents ?? 0;

  return (
    <div className="space-y-6 animate-fade-in">
      <PageHeader title="Billing & Subscription" description="Manage your plan, usage and invoices.">
        <NewInvoiceButton patients={patients.map((p) => ({ id: p.id, label: p.fullName }))} />
      </PageHeader>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Current plan" value={statusLabel(tier)} icon={Zap} hint={sub?.currentPeriodEnd ? `Renews ${format(sub.currentPeriodEnd, "MMM d")}` : "active"} delta={undefined} />
        <StatCard label="Monthly cost" value={formatIDR(monthly / 100)} icon={Receipt} hint="billed monthly" delta={undefined} />
        <StatCard label="Invoices" value={String(invoices.length)} delta={12} icon={TrendingUp} />
        <StatCard label="Outstanding" value={formatIDR(outstanding / 100)} icon={Receipt} hint="unpaid" delta={undefined} />
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-1">
          <CardHeader><CardTitle>Usage this cycle</CardTitle><CardDescription>Plan limits</CardDescription></CardHeader>
          <CardContent className="space-y-4">
            {usage.map((u) => {
              const pct = Math.min(100, Math.round((u.used / u.limit) * 100));
              return (
                <div key={u.label}>
                  <div className="mb-1.5 flex items-center justify-between text-sm"><span>{u.label}</span><span className="tnum text-muted-foreground">{u.used.toLocaleString()} / {u.limit.toLocaleString()}</span></div>
                  <Progress value={pct} className={cn(pct > 85 && "[&>div]:bg-warning")} />
                </div>
              );
            })}
          </CardContent>
        </Card>

        <div className="grid gap-4 sm:grid-cols-3 lg:col-span-2">
          {PLANS.map((p) => {
            const current = p.tier === tier;
            return (
              <Card key={p.tier} className={cn("relative flex flex-col", current && "border-primary ring-1 ring-primary")}>
                {current && <Badge className="absolute -top-2 left-4">Current</Badge>}
                <CardHeader><CardTitle className="text-base">{p.name}</CardTitle>
                  <div className="mt-1"><span className="text-2xl font-semibold tnum">{formatIDR(p.priceCents / 100)}</span><span className="text-sm text-muted-foreground">/mo</span></div></CardHeader>
                <CardContent className="flex flex-1 flex-col">
                  <ul className="flex-1 space-y-2 text-sm">{p.features.map((f) => <li key={f} className="flex items-center gap-2"><Check className="h-4 w-4 text-success" /> {f}</li>)}</ul>
                  <Button variant={current ? "outline" : "default"} className="mt-4 w-full" disabled={current}>{current ? "Current plan" : "Upgrade"}</Button>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>

      <Card className="p-0">
        <CardHeader className="border-b"><CardTitle>Invoices</CardTitle><CardDescription>Patient billing history</CardDescription></CardHeader>
        <Table>
          <TableHeader><TableRow>
            <TableHead>Invoice</TableHead><TableHead>Patient</TableHead>
            <TableHead className="hidden sm:table-cell">Date</TableHead>
            <TableHead className="hidden md:table-cell">Method</TableHead>
            <TableHead className="text-right">Amount</TableHead><TableHead>Status</TableHead><TableHead className="w-10" />
          </TableRow></TableHeader>
          <TableBody>
            {invoices.map((inv) => (
              <TableRow key={inv.id}>
                <TableCell className="font-medium tnum">{inv.number}</TableCell>
                <TableCell>{inv.patient?.fullName ?? "—"}</TableCell>
                <TableCell className="hidden sm:table-cell text-muted-foreground tnum">{format(inv.issuedAt, "yyyy-MM-dd")}</TableCell>
                <TableCell className="hidden md:table-cell text-muted-foreground">{inv.method ?? "—"}</TableCell>
                <TableCell className="text-right font-medium tnum">{formatIDR(inv.amountCents / 100)}</TableCell>
                <TableCell><Badge variant={statusTone[inv.status as keyof typeof statusTone]}>{statusLabel(inv.status)}</Badge></TableCell>
                <TableCell>{inv.status !== "PAID" && inv.status !== "VOID" && <MarkPaidButton id={inv.id} />}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Card>
    </div>
  );
}
