"use client";
import * as React from "react";
import { Plus, Check } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogTrigger } from "@/components/ui/dialog";
import { InvoiceForm } from "@/components/forms/invoice-form";
import { markInvoicePaid } from "@/server/actions/invoices";

export function NewInvoiceButton({ patients }: { patients: { id: string; label: string }[] }) {
  const [open, setOpen] = React.useState(false);
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild><Button><Plus className="h-4 w-4" /> New invoice</Button></DialogTrigger>
      <DialogContent>
        <DialogHeader><DialogTitle>New invoice</DialogTitle><DialogDescription>Bill a patient for a treatment.</DialogDescription></DialogHeader>
        <InvoiceForm patients={patients} onDone={() => setOpen(false)} />
      </DialogContent>
    </Dialog>
  );
}

export function MarkPaidButton({ id }: { id: string }) {
  const [pending, setPending] = React.useState(false);
  async function onPaid() {
    setPending(true); const res = await markInvoicePaid(id); setPending(false);
    if (res.ok) toast.success("Marked paid"); else toast.error(res.error ?? "Failed");
  }
  return <Button size="sm" variant="ghost" disabled={pending} onClick={onPaid}><Check className="h-4 w-4" /> Paid</Button>;
}
