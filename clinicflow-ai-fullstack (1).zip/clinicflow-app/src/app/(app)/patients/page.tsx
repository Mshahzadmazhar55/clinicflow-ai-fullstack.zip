import { Users } from "lucide-react";
import { PageHeader } from "@/components/shared/page-header";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/components/ui/table";
import { EmptyState } from "@/components/shared/empty-state";
import { getPatients } from "@/server/queries";
import { formatIDR, initials, parseTags, statusLabel } from "@/lib/utils";
import { format } from "date-fns";
import { PatientsToolbar, PatientRowActions, AddPatientButton, PatientsPagination } from "./patients-client";

export const dynamic = "force-dynamic";
const statusTone = { ACTIVE: "success", NEW: "default", INACTIVE: "secondary" } as const;

export default async function PatientsPage({ searchParams }: { searchParams: { q?: string; status?: string; page?: string } }) {
  const q = searchParams.q ?? "";
  const status = searchParams.status ?? "all";
  const page = Number(searchParams.page ?? 1);
  const { rows, total, pageCount } = await getPatients({ q, status, page, pageSize: 8 });

  return (
    <div className="space-y-6 animate-fade-in">
      <PageHeader title="Patients" description={`${total} patient${total === 1 ? "" : "s"} in your clinic`}>
        <AddPatientButton />
      </PageHeader>

      <Card className="p-0">
        <PatientsToolbar q={q} status={status} />
        {rows.length === 0 ? (
          <EmptyState icon={Users} title="No patients found"
            description={q ? `No results for "${q}". Try a different search or filter.` : "Add your first patient to get started."} />
        ) : (
          <>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Patient</TableHead>
                  <TableHead className="hidden md:table-cell">Tags</TableHead>
                  <TableHead className="hidden sm:table-cell">Last visit</TableHead>
                  <TableHead className="text-right">Total spent</TableHead>
                  <TableHead>Status</TableHead><TableHead className="w-10" />
                </TableRow>
              </TableHeader>
              <TableBody>
                {rows.map((p) => (
                  <TableRow key={p.id}>
                    <TableCell>
                      <div className="flex items-center gap-3">
                        <Avatar className="h-9 w-9"><AvatarFallback>{initials(p.fullName)}</AvatarFallback></Avatar>
                        <div className="min-w-0"><p className="truncate font-medium">{p.fullName}</p><p className="truncate text-xs text-muted-foreground tnum">{p.phone}</p></div>
                      </div>
                    </TableCell>
                    <TableCell className="hidden md:table-cell">
                      <div className="flex flex-wrap gap-1">{parseTags(p.tagsJson).map((t) => <Badge key={t} variant="secondary">{t}</Badge>)}</div>
                    </TableCell>
                    <TableCell className="hidden sm:table-cell text-sm text-muted-foreground tnum">{p.lastVisitAt ? format(p.lastVisitAt, "yyyy-MM-dd") : "—"}</TableCell>
                    <TableCell className="text-right font-medium tnum">{formatIDR(p.totalSpent / 100)}</TableCell>
                    <TableCell><Badge variant={statusTone[p.status as keyof typeof statusTone]}>{statusLabel(p.status)}</Badge></TableCell>
                    <TableCell>
                      <PatientRowActions patient={{ id: p.id, fullName: p.fullName, phone: p.phone, email: p.email ?? "", gender: (p.gender as any) ?? undefined, status: p.status as any, notes: p.notes ?? "", tags: parseTags(p.tagsJson) }} />
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
            <div className="border-t"><PatientsPagination page={page} pageCount={pageCount} total={total} /></div>
          </>
        )}
      </Card>
    </div>
  );
}
