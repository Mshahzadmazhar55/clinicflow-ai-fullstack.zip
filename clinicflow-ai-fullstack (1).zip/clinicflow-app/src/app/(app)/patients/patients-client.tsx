"use client";
import * as React from "react";
import { useRouter, useSearchParams, usePathname } from "next/navigation";
import { Search, Plus, Filter, X, MoreHorizontal, FileText, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogTrigger } from "@/components/ui/dialog";
import { DropdownMenu, DropdownMenuTrigger, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator } from "@/components/ui/dropdown-menu";
import { PatientForm } from "@/components/forms/patient-form";
import { deletePatient } from "@/server/actions/patients";
import type { PatientInput } from "@/lib/validations/patient";

export function PatientsToolbar({ q, status }: { q: string; status: string }) {
  const router = useRouter(); const pathname = usePathname(); const sp = useSearchParams();
  const [value, setValue] = React.useState(q);

  const push = React.useCallback((params: Record<string, string>) => {
    const next = new URLSearchParams(sp.toString());
    Object.entries(params).forEach(([k, v]) => { if (v && v !== "all") next.set(k, v); else next.delete(k); });
    next.delete("page");
    router.push(`${pathname}?${next.toString()}`);
  }, [router, pathname, sp]);

  React.useEffect(() => {
    const t = setTimeout(() => { if (value !== q) push({ q: value, status }); }, 350);
    return () => clearTimeout(t);
  }, [value]); // eslint-disable-line

  return (
    <div className="flex flex-col gap-3 border-b p-4 sm:flex-row sm:items-center">
      <div className="relative flex-1">
        <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input placeholder="Search by name, phone or email…" value={value} onChange={(e) => setValue(e.target.value)} className="pl-9" />
        {value && <button onClick={() => { setValue(""); push({ q: "", status }); }} className="absolute right-3 top-1/2 -translate-y-1/2"><X className="h-4 w-4 text-muted-foreground" /></button>}
      </div>
      <Select value={status} onValueChange={(v) => push({ q: value, status: v })}>
        <SelectTrigger className="w-full sm:w-40"><Filter className="h-4 w-4" /><SelectValue /></SelectTrigger>
        <SelectContent>
          <SelectItem value="all">All status</SelectItem><SelectItem value="active">Active</SelectItem>
          <SelectItem value="new">New</SelectItem><SelectItem value="inactive">Inactive</SelectItem>
        </SelectContent>
      </Select>
    </div>
  );
}

export function AddPatientButton() {
  const [open, setOpen] = React.useState(false);
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild><Button><Plus className="h-4 w-4" /> Add patient</Button></DialogTrigger>
      <DialogContent>
        <DialogHeader><DialogTitle>Add patient</DialogTitle><DialogDescription>Create a new patient record.</DialogDescription></DialogHeader>
        <PatientForm onDone={() => setOpen(false)} />
      </DialogContent>
    </Dialog>
  );
}

export function PatientRowActions({ patient }: { patient: PatientInput & { id: string } }) {
  const [edit, setEdit] = React.useState(false);
  async function onDelete() {
    if (!confirm(`Delete ${patient.fullName}? This cannot be undone.`)) return;
    const res = await deletePatient(patient.id);
    if (res.ok) toast.success("Patient deleted"); else toast.error(res.error ?? "Failed to delete");
  }
  return (
    <>
      <DropdownMenu>
        <DropdownMenuTrigger asChild><Button variant="ghost" size="icon"><MoreHorizontal className="h-4 w-4" /></Button></DropdownMenuTrigger>
        <DropdownMenuContent align="end">
          <DropdownMenuItem onClick={() => setEdit(true)}><FileText className="h-4 w-4" /> Edit</DropdownMenuItem>
          <DropdownMenuSeparator />
          <DropdownMenuItem className="text-destructive" onClick={onDelete}><Trash2 className="h-4 w-4" /> Delete</DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
      <Dialog open={edit} onOpenChange={setEdit}>
        <DialogContent>
          <DialogHeader><DialogTitle>Edit patient</DialogTitle><DialogDescription>Update {patient.fullName}'s record.</DialogDescription></DialogHeader>
          <PatientForm defaults={patient} onDone={() => setEdit(false)} />
        </DialogContent>
      </Dialog>
    </>
  );
}

export function PatientsPagination({ page, pageCount, total }: { page: number; pageCount: number; total: number }) {
  const router = useRouter(); const pathname = usePathname(); const sp = useSearchParams();
  function go(p: number) {
    const next = new URLSearchParams(sp.toString());
    next.set("page", String(p));
    router.push(`${pathname}?${next.toString()}`);
  }
  return (
    <div className="flex items-center justify-between gap-2 px-3 py-3">
      <p className="text-sm text-muted-foreground">Page <span className="tnum font-medium text-foreground">{page}</span> of <span className="tnum">{pageCount}</span> · {total} total</p>
      <div className="flex items-center gap-1">
        <Button variant="outline" size="sm" disabled={page <= 1} onClick={() => go(page - 1)}>Prev</Button>
        <Button variant="outline" size="sm" disabled={page >= pageCount} onClick={() => go(page + 1)}>Next</Button>
      </div>
    </div>
  );
}
