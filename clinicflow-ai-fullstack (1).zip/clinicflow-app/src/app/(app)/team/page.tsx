import { Shield } from "lucide-react";
import { PageHeader } from "@/components/shared/page-header";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/components/ui/table";
import { getTeam } from "@/server/queries";
import { initials, statusLabel } from "@/lib/utils";
import { formatDistanceToNow } from "date-fns";
import { InviteButton, MemberActions } from "./team-client";

export const dynamic = "force-dynamic";
const roleTone: Record<string, "default" | "secondary" | "success" | "warning"> = { ADMIN: "default", MANAGER: "success", DOCTOR: "warning", RECEPTIONIST: "secondary", STAFF: "secondary" };

export default async function TeamPage() {
  const members = await getTeam();
  const pending = members.filter((m) => m.status === "INVITED").length;
  return (
    <div className="space-y-6 animate-fade-in">
      <PageHeader title="Team" description={`${members.length} members${pending ? ` · ${pending} pending invite${pending > 1 ? "s" : ""}` : ""}`}>
        <InviteButton />
      </PageHeader>
      <Card className="p-0">
        <Table>
          <TableHeader><TableRow>
            <TableHead>Member</TableHead><TableHead>Role</TableHead>
            <TableHead className="hidden sm:table-cell">Last active</TableHead>
            <TableHead>Status</TableHead><TableHead className="w-10" />
          </TableRow></TableHeader>
          <TableBody>
            {members.map((m) => (
              <TableRow key={m.id}>
                <TableCell><div className="flex items-center gap-3"><Avatar><AvatarFallback>{initials(m.name)}</AvatarFallback></Avatar>
                  <div><p className="font-medium">{m.name}</p><p className="text-xs text-muted-foreground">{m.email}</p></div></div></TableCell>
                <TableCell><Badge variant={roleTone[m.role]} className="gap-1"><Shield className="h-3 w-3" /> {statusLabel(m.role)}</Badge></TableCell>
                <TableCell className="hidden sm:table-cell text-sm text-muted-foreground">{m.lastActiveAt ? formatDistanceToNow(m.lastActiveAt, { addSuffix: true }) : "—"}</TableCell>
                <TableCell><Badge variant={m.status === "ACTIVE" ? "success" : "warning"}>{statusLabel(m.status)}</Badge></TableCell>
                <TableCell><MemberActions member={{ id: m.id, name: m.name, role: m.role, status: m.status }} /></TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Card>
    </div>
  );
}
