"use client";
import * as React from "react";
import { UserPlus, MoreHorizontal, Trash2, Shield } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogTrigger } from "@/components/ui/dialog";
import { DropdownMenu, DropdownMenuTrigger, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuLabel } from "@/components/ui/dropdown-menu";
import { InviteForm } from "@/components/forms/invite-form";
import { updateMember, removeMember } from "@/server/actions/team";
import { ROLES } from "@/lib/constants";
import { statusLabel } from "@/lib/utils";

export function InviteButton() {
  const [open, setOpen] = React.useState(false);
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild><Button><UserPlus className="h-4 w-4" /> Invite member</Button></DialogTrigger>
      <DialogContent>
        <DialogHeader><DialogTitle>Invite a team member</DialogTitle><DialogDescription>They'll get access to your clinic workspace.</DialogDescription></DialogHeader>
        <InviteForm onDone={() => setOpen(false)} />
      </DialogContent>
    </Dialog>
  );
}

export function MemberActions({ member }: { member: { id: string; name: string; role: string; status: string } }) {
  async function setRole(role: string) {
    const res = await updateMember({ id: member.id, role });
    if (res.ok) toast.success(`Role updated to ${statusLabel(role)}`); else toast.error(res.error ?? "Failed");
  }
  async function onRemove() {
    if (!confirm(`Remove ${member.name}?`)) return;
    const res = await removeMember(member.id);
    if (res.ok) toast.success("Member removed"); else toast.error(res.error ?? "Failed");
  }
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild><Button variant="ghost" size="icon"><MoreHorizontal className="h-4 w-4" /></Button></DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        <DropdownMenuLabel className="flex items-center gap-1"><Shield className="h-3 w-3" /> Change role</DropdownMenuLabel>
        {ROLES.filter((r) => r !== member.role).map((r) => <DropdownMenuItem key={r} onClick={() => setRole(r)}>{statusLabel(r)}</DropdownMenuItem>)}
        <DropdownMenuSeparator />
        <DropdownMenuItem className="text-destructive" onClick={onRemove}><Trash2 className="h-4 w-4" /> Remove</DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
