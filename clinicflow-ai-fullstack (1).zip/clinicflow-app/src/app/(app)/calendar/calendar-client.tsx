"use client";
import * as React from "react";
import { Plus } from "lucide-react";
import { startOfWeek, addDays, isSameDay, format, getHours, getMinutes } from "date-fns";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogTrigger } from "@/components/ui/dialog";
import { AppointmentForm } from "@/components/forms/appointment-form";
import { updateAppointmentStatus } from "@/server/actions/appointments";
import { cn, initials, statusLabel } from "@/lib/utils";

type Ev = { id: string; startAt: string; endAt: string; patient: string; service: string; practitioner: string; status: string };
type Opt = { id: string; label: string };
const HOURS = Array.from({ length: 11 }, (_, i) => 8 + i);
const toneFor = (s: string) =>
  s === "REQUESTED" ? "bg-amber-500/15 text-amber-700 dark:text-amber-300 border-amber-500/30"
  : s === "CHECKED_IN" ? "bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 border-emerald-500/30"
  : s === "CANCELED" || s === "NO_SHOW" ? "bg-rose-500/15 text-rose-700 dark:text-rose-300 border-rose-500/30"
  : "bg-violet-500/15 text-violet-700 dark:text-violet-300 border-violet-500/30";

export function NewAppointmentButton({ patients, services, practitioners }: { patients: Opt[]; services: Opt[]; practitioners: Opt[] }) {
  const [open, setOpen] = React.useState(false);
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild><Button><Plus className="h-4 w-4" /> New appointment</Button></DialogTrigger>
      <DialogContent>
        <DialogHeader><DialogTitle>New appointment</DialogTitle><DialogDescription>Book a slot for a patient.</DialogDescription></DialogHeader>
        <AppointmentForm patients={patients} services={services} practitioners={practitioners} onDone={() => setOpen(false)} />
      </DialogContent>
    </Dialog>
  );
}

export function CalendarView({ events }: { events: Ev[] }) {
  const [weekStart, setWeekStart] = React.useState(() => startOfWeek(new Date(), { weekStartsOn: 1 }));
  const days = Array.from({ length: 7 }, (_, i) => addDays(weekStart, i));

  async function cycle(id: string, status: string) {
    const order = ["REQUESTED", "CONFIRMED", "CHECKED_IN", "COMPLETED"];
    const next = order[(order.indexOf(status) + 1) % order.length];
    const res = await updateAppointmentStatus(id, next);
    if (res.ok) toast.success(`Marked ${statusLabel(next)}`); else toast.error(res.error ?? "Failed");
  }

  return (
    <>
      <div className="flex items-center gap-2">
        <Button variant="outline" size="sm" onClick={() => setWeekStart(addDays(weekStart, -7))}>← Prev</Button>
        <Button variant="outline" size="sm" onClick={() => setWeekStart(startOfWeek(new Date(), { weekStartsOn: 1 }))}>This week</Button>
        <Button variant="outline" size="sm" onClick={() => setWeekStart(addDays(weekStart, 7))}>Next →</Button>
        <span className="ml-2 text-sm text-muted-foreground">{format(weekStart, "MMM d")} – {format(addDays(weekStart, 6), "MMM d, yyyy")}</span>
      </div>
      <Card className="overflow-x-auto p-0">
        <div className="min-w-[820px]">
          <div className="grid grid-cols-[64px_repeat(7,1fr)] border-b">
            <div className="border-r p-2" />
            {days.map((d) => {
              const today = isSameDay(d, new Date());
              return <div key={+d} className={cn("p-2 text-center text-sm font-medium", today && "text-primary")}>{format(d, "EEE d")}</div>;
            })}
          </div>
          <div className="grid grid-cols-[64px_repeat(7,1fr)]">
            <div className="border-r">{HOURS.map((h) => <div key={h} className="h-16 px-2 pt-1 text-right text-xs text-muted-foreground">{h}:00</div>)}</div>
            {days.map((d) => (
              <div key={+d} className="relative border-r last:border-r-0">
                {HOURS.map((h) => <div key={h} className="h-16 border-b border-dashed" />)}
                {events.filter((e) => isSameDay(new Date(e.startAt), d)).map((e) => {
                  const start = new Date(e.startAt); const end = new Date(e.endAt);
                  const top = (getHours(start) - 8) * 64 + getMinutes(start) * (64 / 60);
                  const height = Math.max(28, ((+end - +start) / 3600000) * 64 - 4);
                  return (
                    <button key={e.id} onClick={() => cycle(e.id, e.status)}
                      className={cn("absolute inset-x-1 overflow-hidden rounded-lg border p-1.5 text-left text-xs", toneFor(e.status))}
                      style={{ top: top + 2, height }}>
                      <p className="font-semibold leading-tight">{e.service}</p>
                      <p className="flex items-center gap-1 opacity-80"><Avatar className="h-4 w-4"><AvatarFallback className="text-[8px]">{initials(e.patient)}</AvatarFallback></Avatar>{e.patient}</p>
                    </button>
                  );
                })}
              </div>
            ))}
          </div>
        </div>
      </Card>
      <div className="flex flex-wrap gap-2 text-xs">
        <Badge variant="secondary">Tap an appointment to advance its status</Badge>
      </div>
    </>
  );
}
