import { PageHeader } from "@/components/shared/page-header";
import { getCalendar, getPatientOptions } from "@/server/queries";
import { db } from "@/lib/db";
import { getClinicId } from "@/lib/tenant";
import { CalendarView, NewAppointmentButton } from "./calendar-client";

export const dynamic = "force-dynamic";

export default async function CalendarPage() {
  const clinicId = await getClinicId();
  const [{ appts, practitioners }, patients, services] = await Promise.all([
    getCalendar(), getPatientOptions(),
    db.service.findMany({ where: { clinicId, active: true }, select: { id: true, name: true } }),
  ]);
  const events = appts.map((a) => ({
    id: a.id, startAt: a.startAt.toISOString(), endAt: a.endAt.toISOString(),
    patient: a.patient.fullName, service: a.service?.name ?? "Consultation",
    practitioner: a.practitioner?.displayName ?? "—", status: a.status,
  }));
  return (
    <div className="space-y-6 animate-fade-in">
      <PageHeader title="Calendar" description="Upcoming appointments across your practitioners.">
        <NewAppointmentButton
          patients={patients.map((p) => ({ id: p.id, label: p.fullName }))}
          services={services.map((s) => ({ id: s.id, label: s.name }))}
          practitioners={practitioners.map((p) => ({ id: p.id, label: p.displayName }))}
        />
      </PageHeader>
      <CalendarView events={events} />
    </div>
  );
}
