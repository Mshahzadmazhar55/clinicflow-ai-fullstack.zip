"use client";
import * as React from "react";
import { Plus, MoreHorizontal, Send, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogTrigger } from "@/components/ui/dialog";
import { DropdownMenu, DropdownMenuTrigger, DropdownMenuContent, DropdownMenuItem } from "@/components/ui/dropdown-menu";
import { CampaignForm } from "@/components/forms/campaign-form";
import { sendCampaign, deleteCampaign } from "@/server/actions/campaigns";

export function NewCampaignButton({ segments }: { segments: { id: string; label: string }[] }) {
  const [open, setOpen] = React.useState(false);
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild><Button><Plus className="h-4 w-4" /> New campaign</Button></DialogTrigger>
      <DialogContent>
        <DialogHeader><DialogTitle>Create campaign</DialogTitle><DialogDescription>Send a broadcast to a patient segment.</DialogDescription></DialogHeader>
        <CampaignForm segments={segments} onDone={() => setOpen(false)} />
      </DialogContent>
    </Dialog>
  );
}

export function SendCampaignButton({ id }: { id: string }) {
  const [pending, setPending] = React.useState(false);
  async function onSend() {
    setPending(true); const res = await sendCampaign(id); setPending(false);
    if (res.ok) toast.success("Campaign sent"); else toast.error(res.error ?? "Failed");
  }
  return <Button size="sm" variant="outline" disabled={pending} onClick={onSend}><Send className="h-3.5 w-3.5" /> Send</Button>;
}

export function CampaignActions({ id }: { id: string }) {
  async function onDelete() {
    if (!confirm("Delete this campaign?")) return;
    const res = await deleteCampaign(id);
    if (res.ok) toast.success("Campaign deleted"); else toast.error(res.error ?? "Failed");
  }
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild><Button variant="ghost" size="icon"><MoreHorizontal className="h-4 w-4" /></Button></DropdownMenuTrigger>
      <DropdownMenuContent align="end"><DropdownMenuItem className="text-destructive" onClick={onDelete}><Trash2 className="h-4 w-4" /> Delete</DropdownMenuItem></DropdownMenuContent>
    </DropdownMenu>
  );
}
