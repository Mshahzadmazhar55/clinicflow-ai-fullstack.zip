import { Megaphone, Mail, MessageCircle, Users } from "lucide-react";
import { PageHeader } from "@/components/shared/page-header";
import { StatCard } from "@/components/shared/stat-card";
import { Card, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/components/ui/table";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { getCampaigns } from "@/server/queries";
import { statusLabel } from "@/lib/utils";
import { format } from "date-fns";
import { NewCampaignButton, CampaignActions, SendCampaignButton } from "./marketing-client";

export const dynamic = "force-dynamic";
const statusTone = { SENT: "success", SENDING: "default", SCHEDULED: "warning", DRAFT: "secondary" } as const;

export default async function MarketingPage() {
  const { campaigns, segments } = await getCampaigns();
  const sent = campaigns.filter((c) => c.status === "SENT");
  const avgOpen = sent.length ? Math.round(sent.reduce((s, c) => s + c.openRate, 0) / sent.length) : 0;
  return (
    <div className="space-y-6 animate-fade-in">
      <PageHeader title="Marketing" description="Reach patients on WhatsApp and email.">
        <NewCampaignButton segments={segments.map((s) => ({ id: s.id, label: `${s.name} (${s.count})` }))} />
      </PageHeader>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Campaigns" value={String(campaigns.length)} icon={Megaphone} hint="all time" delta={undefined} />
        <StatCard label="Sent" value={String(sent.length)} icon={MessageCircle} hint="delivered" delta={undefined} />
        <StatCard label="Avg. open rate" value={`${avgOpen}%`} delta={4} icon={Mail} />
        <StatCard label="Segments" value={String(segments.length)} icon={Users} hint="audiences" delta={undefined} />
      </div>

      <Tabs defaultValue="campaigns">
        <TabsList><TabsTrigger value="campaigns">Campaigns</TabsTrigger><TabsTrigger value="segments">Segments</TabsTrigger></TabsList>
        <TabsContent value="campaigns">
          <Card className="p-0">
            <Table>
              <TableHeader><TableRow>
                <TableHead>Campaign</TableHead><TableHead>Channel</TableHead>
                <TableHead className="hidden md:table-cell">Segment</TableHead>
                <TableHead className="text-right">Recipients</TableHead>
                <TableHead className="text-right hidden sm:table-cell">Open</TableHead>
                <TableHead>Status</TableHead><TableHead className="w-10" />
              </TableRow></TableHeader>
              <TableBody>
                {campaigns.map((c) => (
                  <TableRow key={c.id}>
                    <TableCell className="font-medium">{c.name}<div className="text-xs text-muted-foreground tnum">{c.sentAt ? format(c.sentAt, "yyyy-MM-dd") : c.scheduledAt ? `Scheduled ${format(c.scheduledAt, "MMM d")}` : "—"}</div></TableCell>
                    <TableCell><Badge variant="outline" className="gap-1">{c.channel === "WHATSAPP" ? <MessageCircle className="h-3 w-3" /> : <Mail className="h-3 w-3" />}{statusLabel(c.channel)}</Badge></TableCell>
                    <TableCell className="hidden md:table-cell text-sm text-muted-foreground">{c.segment?.name ?? "All patients"}</TableCell>
                    <TableCell className="text-right tnum">{c.recipients.toLocaleString()}</TableCell>
                    <TableCell className="text-right tnum hidden sm:table-cell">{c.openRate ? `${c.openRate}%` : "—"}</TableCell>
                    <TableCell><Badge variant={statusTone[c.status as keyof typeof statusTone]}>{statusLabel(c.status)}</Badge></TableCell>
                    <TableCell><div className="flex items-center gap-1">{(c.status === "DRAFT" || c.status === "SCHEDULED") && <SendCampaignButton id={c.id} />}<CampaignActions id={c.id} /></div></TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </Card>
        </TabsContent>
        <TabsContent value="segments">
          <div className="grid gap-4 sm:grid-cols-2">
            {segments.map((s) => (
              <Card key={s.id}>
                <CardHeader><CardTitle className="text-base">{s.name}</CardTitle><CardDescription>{s.count} patients</CardDescription></CardHeader>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
