import { Building2, Bot, MessageCircle, Bell } from "lucide-react";
import { PageHeader } from "@/components/shared/page-header";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { getSettings } from "@/server/queries";
import { ClinicForm, AiForm, WhatsAppPanel, NotifSwitch } from "./settings-client";

export const dynamic = "force-dynamic";

export default async function SettingsPage() {
  const { clinic, wa } = await getSettings();
  return (
    <div className="space-y-6 animate-fade-in">
      <PageHeader title="Settings" description="Configure your clinic, AI receptionist and integrations." />
      <Tabs defaultValue="clinic">
        <TabsList className="flex-wrap">
          <TabsTrigger value="clinic"><Building2 className="mr-1.5 h-4 w-4" />Clinic</TabsTrigger>
          <TabsTrigger value="ai"><Bot className="mr-1.5 h-4 w-4" />AI receptionist</TabsTrigger>
          <TabsTrigger value="whatsapp"><MessageCircle className="mr-1.5 h-4 w-4" />WhatsApp</TabsTrigger>
          <TabsTrigger value="notifications"><Bell className="mr-1.5 h-4 w-4" />Notifications</TabsTrigger>
        </TabsList>

        <TabsContent value="clinic">
          <Card>
            <CardHeader><CardTitle>Clinic profile</CardTitle><CardDescription>Shown to patients on bookings and messages.</CardDescription></CardHeader>
            <CardContent>
              <ClinicForm defaults={{ name: clinic?.name ?? "", phone: clinic?.phone ?? "", city: clinic?.city ?? "", address: clinic?.address ?? "", timezone: clinic?.timezone ?? "Asia/Jakarta" }} />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="ai">
          <Card>
            <CardHeader><CardTitle>AI receptionist</CardTitle><CardDescription>How the AI handles WhatsApp conversations.</CardDescription></CardHeader>
            <CardContent>
              <AiForm defaults={{ aiEnabled: wa?.aiEnabled ?? true, aiLanguage: (wa?.aiLanguage as any) ?? "auto", aiPersona: wa?.aiPersona ?? "", remindersOn: wa?.remindersOn ?? true, followupsOn: wa?.followupsOn ?? true }} />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="whatsapp">
          <Card>
            <CardHeader className="flex-row items-center justify-between">
              <div><CardTitle>WhatsApp Business API</CardTitle><CardDescription>Connected via Meta Cloud API.</CardDescription></div>
              <Badge variant={wa?.phoneNumberId ? "success" : "secondary"}>{wa?.phoneNumberId ? "Connected" : "Not connected"}</Badge>
            </CardHeader>
            <CardContent><WhatsAppPanel phoneNumberId={wa?.phoneNumberId ?? ""} phone={clinic?.whatsappNumber ?? ""} /></CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="notifications">
          <Card>
            <CardHeader><CardTitle>Notifications</CardTitle><CardDescription>What you get pinged about.</CardDescription></CardHeader>
            <CardContent><NotificationRows /></CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

function NotificationRows() {
  const rows = [
    ["New booking", "When a patient books via WhatsApp or web."],
    ["Conversation needs human", "When AI escalates a chat to staff."],
    ["Daily summary email", "A 7 AM digest of the day ahead."],
    ["Overdue invoices", "When an invoice passes its due date."],
  ];
  return (
    <div className="divide-y">
      {rows.map(([t, d], i) => (
        <div key={t} className="flex items-center justify-between gap-4 py-3">
          <div><p className="text-sm font-medium">{t}</p><p className="text-xs text-muted-foreground">{d}</p></div>
          <NotifSwitch defaultChecked={i !== 2} />
        </div>
      ))}
    </div>
  );
}

