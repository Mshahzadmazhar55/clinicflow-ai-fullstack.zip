"use client";
import * as React from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { Check } from "lucide-react";
import { clinicSchema, type ClinicInput, aiSchema, type AiInput } from "@/lib/validations/settings";
import { updateClinic, updateAi } from "@/server/actions/settings";
import { Form, FormField, FormItem, FormLabel, FormControl, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select";

export function ClinicForm({ defaults }: { defaults: ClinicInput }) {
  const router = useRouter(); const [pending, setPending] = React.useState(false);
  const form = useForm<ClinicInput>({ resolver: zodResolver(clinicSchema), defaultValues: defaults });
  async function onSubmit(v: ClinicInput) {
    setPending(true); const res = await updateClinic(v); setPending(false);
    if (res.ok) { toast.success("Clinic profile saved"); router.refresh(); }
    else if (res.fieldErrors) Object.entries(res.fieldErrors).forEach(([k, val]) => form.setError(k as any, { message: val?.[0] }));
    else toast.error(res.error ?? "Failed");
  }
  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <div className="grid gap-4 sm:grid-cols-2">
          <FormField control={form.control} name="name" render={({ field }) => (<FormItem><FormLabel>Clinic name</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>)} />
          <FormField control={form.control} name="phone" render={({ field }) => (<FormItem><FormLabel>Phone</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>)} />
          <FormField control={form.control} name="city" render={({ field }) => (<FormItem><FormLabel>City</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>)} />
          <FormField control={form.control} name="timezone" render={({ field }) => (
            <FormItem><FormLabel>Timezone</FormLabel>
              <Select onValueChange={field.onChange} value={field.value}>
                <FormControl><SelectTrigger><SelectValue /></SelectTrigger></FormControl>
                <SelectContent><SelectItem value="Asia/Jakarta">Asia/Jakarta (WIB)</SelectItem><SelectItem value="Asia/Makassar">Asia/Makassar (WITA)</SelectItem><SelectItem value="Asia/Jayapura">Asia/Jayapura (WIT)</SelectItem></SelectContent>
              </Select><FormMessage /></FormItem>
          )} />
        </div>
        <FormField control={form.control} name="address" render={({ field }) => (<FormItem><FormLabel>Address</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>)} />
        <div className="flex justify-end"><Button type="submit" disabled={pending}><Check className="h-4 w-4" /> {pending ? "Saving…" : "Save changes"}</Button></div>
      </form>
    </Form>
  );
}

export function AiForm({ defaults }: { defaults: AiInput }) {
  const router = useRouter(); const [pending, setPending] = React.useState(false);
  const form = useForm<AiInput>({ resolver: zodResolver(aiSchema), defaultValues: defaults });
  async function onSubmit(v: AiInput) {
    setPending(true); const res = await updateAi(v); setPending(false);
    if (res.ok) { toast.success("AI settings saved"); router.refresh(); } else toast.error(res.error ?? "Failed");
  }
  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="divide-y">
        <FormField control={form.control} name="aiEnabled" render={({ field }) => (
          <div className="flex items-center justify-between py-3"><div><p className="text-sm font-medium">Enable AI auto-reply</p><p className="text-xs text-muted-foreground">AI answers and books appointments automatically.</p></div><Switch checked={field.value} onCheckedChange={field.onChange} /></div>
        )} />
        <FormField control={form.control} name="aiLanguage" render={({ field }) => (
          <div className="flex items-center justify-between py-3"><div><p className="text-sm font-medium">Reply language</p><p className="text-xs text-muted-foreground">AI matches the patient's language by default.</p></div>
            <Select onValueChange={field.onChange} value={field.value}><SelectTrigger className="w-36"><SelectValue /></SelectTrigger>
              <SelectContent><SelectItem value="auto">Auto</SelectItem><SelectItem value="id">Bahasa</SelectItem><SelectItem value="en">English</SelectItem></SelectContent></Select></div>
        )} />
        <div className="py-4"><FormField control={form.control} name="aiPersona" render={({ field }) => (
          <FormItem><FormLabel>Persona / tone</FormLabel><FormControl><Textarea rows={3} {...field} /></FormControl><FormMessage /></FormItem>)} /></div>
        <div className="flex justify-end pt-4"><Button type="submit" disabled={pending}>{pending ? "Saving…" : "Save AI settings"}</Button></div>
      </form>
    </Form>
  );
}

export function WhatsAppPanel({ phoneNumberId, phone }: { phoneNumberId: string; phone: string }) {
  return (
    <div className="space-y-4">
      <div className="grid gap-4 sm:grid-cols-2">
        <div className="space-y-2"><label className="text-sm font-medium">Phone number</label><Input defaultValue={phone} disabled /></div>
        <div className="space-y-2"><label className="text-sm font-medium">Phone number ID</label><Input defaultValue={phoneNumberId} disabled /></div>
      </div>
      <Separator />
      <div className="flex items-center justify-between py-1"><div><p className="text-sm font-medium">Send appointment reminders</p><p className="text-xs text-muted-foreground">WhatsApp template sent 24h and 2h before.</p></div><Switch defaultChecked /></div>
      <div className="flex items-center justify-between py-1"><div><p className="text-sm font-medium">Send follow-up messages</p><p className="text-xs text-muted-foreground">Post-visit care and rebooking nudges.</p></div><Switch defaultChecked /></div>
      <div className="flex justify-end"><Button variant="outline">Reconnect</Button></div>
    </div>
  );
}

export function NotifSwitch({ defaultChecked }: { defaultChecked?: boolean }) {
  return <Switch defaultChecked={defaultChecked} onCheckedChange={() => toast.success("Notification preference saved")} />;
}
