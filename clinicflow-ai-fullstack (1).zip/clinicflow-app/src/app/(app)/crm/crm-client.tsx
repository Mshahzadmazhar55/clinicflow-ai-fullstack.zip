"use client";
import * as React from "react";
import { Plus, MoreHorizontal, Instagram, MessageCircle, Globe, Users2, Trash2, ArrowRight } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogTrigger } from "@/components/ui/dialog";
import { DropdownMenu, DropdownMenuTrigger, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuLabel } from "@/components/ui/dropdown-menu";
import { LeadForm } from "@/components/forms/lead-form";
import { moveLead, deleteLead } from "@/server/actions/leads";
import { formatIDR, statusLabel } from "@/lib/utils";

type Lead = { id: string; name: string; source: string; interest: string | null; valueCents: number; stage: string };
const meta: Record<string, { title: string; tone: string }> = {
  NEW: { title: "New", tone: "bg-zinc-400" }, CONTACTED: { title: "Contacted", tone: "bg-blue-400" },
  QUALIFIED: { title: "Qualified", tone: "bg-amber-400" }, CONSULT: { title: "Consultation", tone: "bg-violet-400" },
  CONVERTED: { title: "Converted", tone: "bg-emerald-500" }, LOST: { title: "Lost", tone: "bg-rose-400" },
};
const sourceIcon: Record<string, React.ElementType> = { INSTAGRAM: Instagram, WHATSAPP: MessageCircle, WEBSITE: Globe, GOOGLE: Globe, TIKTOK: Globe, REFERRAL: Users2, WALK_IN: Users2 };

export function NewLeadButton() {
  const [open, setOpen] = React.useState(false);
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild><Button><Plus className="h-4 w-4" /> New lead</Button></DialogTrigger>
      <DialogContent>
        <DialogHeader><DialogTitle>New lead</DialogTitle><DialogDescription>Add a lead to your pipeline.</DialogDescription></DialogHeader>
        <LeadForm onDone={() => setOpen(false)} />
      </DialogContent>
    </Dialog>
  );
}

export function CrmBoard({ leads, stages }: { leads: Lead[]; stages: string[] }) {
  async function onMove(id: string, stage: string) {
    const res = await moveLead({ id, stage });
    if (res.ok) toast.success(`Moved to ${meta[stage].title}`); else toast.error(res.error ?? "Failed");
  }
  async function onDelete(id: string) {
    const res = await deleteLead(id);
    if (res.ok) toast.success("Lead removed"); else toast.error(res.error ?? "Failed");
  }
  const visible = stages.filter((s) => s !== "LOST");
  return (
    <div className="grid gap-4 overflow-x-auto md:grid-cols-2 xl:grid-cols-5">
      {visible.map((stage) => {
        const items = leads.filter((l) => l.stage === stage);
        return (
          <div key={stage} className="flex min-w-[260px] flex-col gap-3">
            <div className="flex items-center justify-between px-1">
              <div className="flex items-center gap-2">
                <span className={`h-2.5 w-2.5 rounded-full ${meta[stage].tone}`} />
                <h3 className="text-sm font-semibold">{meta[stage].title}</h3>
                <Badge variant="secondary">{items.length}</Badge>
              </div>
            </div>
            <div className="flex flex-col gap-2">
              {items.map((l) => {
                const Icon = sourceIcon[l.source] ?? Globe;
                const idx = stages.indexOf(l.stage);
                const nextStage = stages[idx + 1];
                return (
                  <Card key={l.id} className="p-3 transition-shadow hover:shadow-md">
                    <div className="flex items-start justify-between">
                      <p className="text-sm font-medium">{l.name}</p>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild><button><MoreHorizontal className="h-4 w-4 text-muted-foreground" /></button></DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuLabel>Move to</DropdownMenuLabel>
                          {stages.filter((s) => s !== l.stage).map((s) => (
                            <DropdownMenuItem key={s} onClick={() => onMove(l.id, s)}>{meta[s].title}</DropdownMenuItem>
                          ))}
                          <DropdownMenuSeparator />
                          <DropdownMenuItem className="text-destructive" onClick={() => onDelete(l.id)}><Trash2 className="h-4 w-4" /> Delete</DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                    <p className="mt-1 text-xs text-muted-foreground">{l.interest ?? "—"}</p>
                    <div className="mt-3 flex items-center justify-between">
                      <Badge variant="outline" className="gap-1"><Icon className="h-3 w-3" /> {statusLabel(l.source)}</Badge>
                      <span className="text-xs font-medium tnum">{formatIDR(l.valueCents / 100)}</span>
                    </div>
                    {nextStage && (
                      <Button variant="ghost" size="sm" className="mt-2 h-7 w-full justify-between text-xs" onClick={() => onMove(l.id, nextStage)}>
                        Move to {meta[nextStage].title} <ArrowRight className="h-3 w-3" />
                      </Button>
                    )}
                  </Card>
                );
              })}
              {items.length === 0 && <div className="rounded-lg border border-dashed py-8 text-center text-xs text-muted-foreground">No leads</div>}
            </div>
          </div>
        );
      })}
    </div>
  );
}
