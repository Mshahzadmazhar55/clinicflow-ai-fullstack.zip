import { PageHeader } from "@/components/shared/page-header";
import { getLeadBoard } from "@/server/queries";
import { LEAD_STAGES } from "@/lib/constants";
import { CrmBoard, NewLeadButton } from "./crm-client";

export const dynamic = "force-dynamic";

export default async function CrmPage() {
  const leads = await getLeadBoard();
  const total = leads.filter((l) => l.stage !== "LOST").length;
  const pipelineValue = leads.filter((l) => l.stage !== "LOST" && l.stage !== "CONVERTED").reduce((s, l) => s + l.valueCents, 0);
  return (
    <div className="space-y-6 animate-fade-in">
      <PageHeader title="CRM Pipeline" description={`${total} active leads · ${(pipelineValue / 100).toLocaleString("id-ID", { style: "currency", currency: "IDR", maximumFractionDigits: 0 })} in pipeline`}>
        <NewLeadButton />
      </PageHeader>
      <CrmBoard leads={leads.map((l) => ({ id: l.id, name: l.name, source: l.source, interest: l.interest, valueCents: l.valueCents, stage: l.stage }))} stages={LEAD_STAGES as unknown as string[]} />
    </div>
  );
}
