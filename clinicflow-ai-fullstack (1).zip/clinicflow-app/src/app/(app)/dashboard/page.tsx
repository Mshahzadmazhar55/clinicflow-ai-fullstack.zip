import { CalendarCheck, DollarSign, Users, Bot, ArrowRight, Sparkles } from "lucide-react";
import Link from "next/link";
import { PageHeader } from "@/components/shared/page-header";
import { StatCard } from "@/components/shared/stat-card";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { AreaRevenue } from "@/components/charts/area-revenue";
import { getDashboard } from "@/server/queries";
import { getCurrentUser } from "@/lib/tenant";
import { formatIDR, initials, statusLabel } from "@/lib/utils";
import { format } from "date-fns";

export const dynamic = "force-dynamic";

const apptTone: Record<string, "default" | "success" | "warning" | "secondary"> = {
  CONFIRMED: "default", CHECKED_IN: "success", REQUESTED: "warning", COMPLETED: "secondary", CANCELED: "secondary", NO_SHOW: "secondary",
};
const convoTone: Record<string, "default" | "warning" | "secondary"> = { AI: "default", NEEDS_HUMAN: "warning", CLOSED: "secondary" };

export default async function DashboardPage() {
  const [{ stats, todays, recentConvos, revenueSeries }, me] = await Promise.all([getDashboard(), getCurrentUser()]);
  const firstName = me.name.split(" ")[0];
  return (
    <div className="space-y-6 animate-fade-in">
      <PageHeader title={`Good morning, ${firstName} 👋`} description="Here's what's happening at your clinic today.">
        <Button variant="outline"><Sparkles className="h-4 w-4" /> AI insights</Button>
      </PageHeader>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Appointments today" value={String(stats.todayCount)} delta={12} icon={CalendarCheck} />
        <StatCard label="Revenue (today)" value={formatIDR(stats.revenueToday / 100)} delta={8} icon={DollarSign} />
        <StatCard label="Total patients" value={stats.patients.toLocaleString()} delta={5} icon={Users} />
        <StatCard label="Open leads" value={String(stats.leads)} delta={-3} icon={Bot} />
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader className="flex-row items-center justify-between">
            <div><CardTitle>Revenue trend</CardTitle><CardDescription>Last 6 months · in million IDR</CardDescription></div>
            <Badge variant="success">Live</Badge>
          </CardHeader>
          <CardContent><AreaRevenue data={revenueSeries} /></CardContent>
        </Card>

        <Card>
          <CardHeader className="flex-row items-center justify-between">
            <CardTitle className="flex items-center gap-2"><Bot className="h-4 w-4 text-primary" /> AI inbox</CardTitle>
            <Link href="/inbox"><Button variant="ghost" size="sm">Open <ArrowRight className="h-4 w-4" /></Button></Link>
          </CardHeader>
          <CardContent className="space-y-1">
            {recentConvos.length === 0 && <p className="px-2 py-6 text-center text-sm text-muted-foreground">No conversations yet.</p>}
            {recentConvos.map((c) => (
              <div key={c.id} className="flex items-center gap-3 rounded-lg p-2 hover:bg-muted">
                <Avatar className="h-8 w-8"><AvatarFallback>{initials(c.contactName)}</AvatarFallback></Avatar>
                <div className="min-w-0 flex-1"><p className="truncate text-sm font-medium">{c.contactName}</p><p className="truncate text-xs text-muted-foreground tnum">{c.phone}</p></div>
                <Badge variant={convoTone[c.status]}>{statusLabel(c.status)}</Badge>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader className="flex-row items-center justify-between">
          <div><CardTitle>Today's schedule</CardTitle><CardDescription>{todays.length} appointments</CardDescription></div>
          <Link href="/calendar"><Button variant="ghost" size="sm">View calendar <ArrowRight className="h-4 w-4" /></Button></Link>
        </CardHeader>
        <CardContent className="space-y-1">
          {todays.length === 0 && <p className="px-2 py-6 text-center text-sm text-muted-foreground">Nothing booked today yet.</p>}
          {todays.map((a) => (
            <div key={a.id} className="flex items-center gap-3 rounded-lg p-2 hover:bg-muted">
              <div className="w-14 text-sm font-medium tnum text-muted-foreground">{format(a.startAt, "HH:mm")}</div>
              <Avatar className="h-8 w-8"><AvatarFallback>{initials(a.patient.fullName)}</AvatarFallback></Avatar>
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-medium">{a.patient.fullName}</p>
                <p className="truncate text-xs text-muted-foreground">{a.service?.name ?? "Consultation"} · {a.practitioner?.displayName ?? "—"}</p>
              </div>
              <Badge variant={apptTone[a.status]}>{statusLabel(a.status)}</Badge>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );
}
