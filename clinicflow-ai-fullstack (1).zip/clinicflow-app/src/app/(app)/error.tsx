"use client";
import { ErrorState } from "@/components/shared/error-state";
export default function Error({ reset }: { error: Error; reset: () => void }) {
  return <div className="pt-10"><ErrorState onRetry={reset} /></div>;
}
