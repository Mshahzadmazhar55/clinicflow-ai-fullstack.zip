import { PageHeader } from "@/components/shared/page-header";
import { getConversations } from "@/server/queries";
import { InboxView } from "./inbox-client";

export const dynamic = "force-dynamic";

export default async function InboxPage() {
  const convos = await getConversations();
  const data = convos.map((c) => ({
    id: c.id, name: c.contactName, phone: c.phone, status: c.status, unread: c.unread,
    messages: c.messages.map((m) => ({ sender: m.sender, body: m.body, time: m.createdAt.toISOString() })),
  }));
  return (
    <div className="space-y-4 animate-fade-in">
      <PageHeader title="WhatsApp Inbox" description="AI receptionist handling conversations in real time." />
      <InboxView conversations={data} />
    </div>
  );
}
