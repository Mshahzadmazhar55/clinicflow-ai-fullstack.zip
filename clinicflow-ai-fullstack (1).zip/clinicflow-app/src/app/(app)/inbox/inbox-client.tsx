"use client";
import * as React from "react";
import { Search, Send, Bot, UserCheck, Paperclip, Sparkles, Phone, MoreVertical } from "lucide-react";
import { format } from "date-fns";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Switch } from "@/components/ui/switch";
import { EmptyState } from "@/components/shared/empty-state";
import { cn, initials, statusLabel } from "@/lib/utils";
import { MessagesSquare } from "lucide-react";

type Msg = { sender: string; body: string; time: string };
type Convo = { id: string; name: string; phone: string; status: string; unread: number; messages: Msg[] };
const tone: Record<string, "default" | "warning" | "secondary"> = { AI: "default", NEEDS_HUMAN: "warning", CLOSED: "secondary" };

export function InboxView({ conversations }: { conversations: Convo[] }) {
  const [activeId, setActiveId] = React.useState(conversations[0]?.id ?? "");
  const [aiOn, setAiOn] = React.useState(true);
  const [draft, setDraft] = React.useState("");
  const [localMsgs, setLocalMsgs] = React.useState<Record<string, Msg[]>>({});
  const current = conversations.find((c) => c.id === activeId);

  if (conversations.length === 0) {
    return <EmptyState icon={MessagesSquare} title="No conversations yet" description="Incoming WhatsApp chats will appear here once your number is connected." />;
  }

  const thread = current ? [...current.messages, ...(localMsgs[current.id] ?? [])] : [];
  function send() {
    if (!draft.trim() || !current) return;
    setLocalMsgs((m) => ({ ...m, [current.id]: [...(m[current.id] ?? []), { sender: "STAFF", body: draft, time: new Date().toISOString() }] }));
    setDraft("");
  }

  return (
    <Card className="grid h-[calc(100vh-200px)] grid-cols-1 overflow-hidden p-0 md:grid-cols-[300px_1fr]">
      <div className="flex flex-col border-r">
        <div className="border-b p-3">
          <div className="relative"><Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" /><Input placeholder="Search chats…" className="pl-9" /></div>
        </div>
        <div className="flex-1 overflow-y-auto">
          {conversations.map((c) => (
            <button key={c.id} onClick={() => setActiveId(c.id)}
              className={cn("flex w-full items-center gap-3 border-b px-3 py-3 text-left transition-colors hover:bg-muted", activeId === c.id && "bg-accent/60")}>
              <Avatar><AvatarFallback>{initials(c.name)}</AvatarFallback></Avatar>
              <div className="min-w-0 flex-1">
                <div className="flex items-center justify-between gap-2"><p className="truncate text-sm font-medium">{c.name}</p>{c.unread > 0 && <span className="flex h-4 min-w-4 items-center justify-center rounded-full bg-primary px-1 text-[10px] text-primary-foreground">{c.unread}</span>}</div>
                <p className="truncate text-xs text-muted-foreground">{c.messages.at(-1)?.body ?? ""}</p>
                <Badge variant={tone[c.status]} className="mt-1 h-4 px-1.5 text-[10px]">{statusLabel(c.status)}</Badge>
              </div>
            </button>
          ))}
        </div>
      </div>

      <div className="flex min-w-0 flex-col">
        {current && (<>
          <div className="flex items-center justify-between gap-2 border-b p-3">
            <div className="flex items-center gap-3"><Avatar><AvatarFallback>{initials(current.name)}</AvatarFallback></Avatar>
              <div><p className="text-sm font-medium">{current.name}</p><p className="text-xs text-muted-foreground tnum">{current.phone}</p></div></div>
            <div className="flex items-center gap-2">
              <div className="hidden items-center gap-2 rounded-lg border px-2.5 py-1.5 sm:flex"><Bot className="h-4 w-4 text-primary" /><span className="text-xs font-medium">AI auto-reply</span><Switch checked={aiOn} onCheckedChange={setAiOn} /></div>
              <Button variant="outline" size="sm"><UserCheck className="h-4 w-4" /> Take over</Button>
              <Button variant="ghost" size="icon"><Phone className="h-4 w-4" /></Button>
              <Button variant="ghost" size="icon"><MoreVertical className="h-4 w-4" /></Button>
            </div>
          </div>
          <div className="flex-1 space-y-3 overflow-y-auto bg-muted/30 p-4">
            {thread.map((m, i) => (
              <div key={i} className={cn("flex", m.sender === "PATIENT" ? "justify-start" : "justify-end")}>
                <div className={cn("max-w-[78%] rounded-2xl px-3.5 py-2 text-sm shadow-sm",
                  m.sender === "PATIENT" ? "rounded-bl-sm bg-card" : m.sender === "AI" ? "rounded-br-sm bg-primary text-primary-foreground" : "rounded-br-sm bg-secondary")}>
                  {m.sender === "AI" && <span className="mb-0.5 flex items-center gap-1 text-[10px] opacity-80"><Sparkles className="h-3 w-3" /> AI receptionist</span>}
                  <p>{m.body}</p>
                  <span className={cn("mt-1 block text-right text-[10px]", m.sender === "PATIENT" ? "text-muted-foreground" : "opacity-70")}>{format(new Date(m.time), "HH:mm")}</span>
                </div>
              </div>
            ))}
          </div>
          <div className="flex items-center gap-2 border-t p-3">
            <Button variant="ghost" size="icon"><Paperclip className="h-4 w-4" /></Button>
            <Input placeholder={aiOn ? "AI is handling this chat — type to take over…" : "Type a reply…"} value={draft} onChange={(e) => setDraft(e.target.value)} onKeyDown={(e) => e.key === "Enter" && send()} />
            <Button size="icon" disabled={!draft.trim()} onClick={send}><Send className="h-4 w-4" /></Button>
          </div>
        </>)}
      </div>
    </Card>
  );
}
