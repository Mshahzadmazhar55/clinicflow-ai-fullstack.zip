import { NextRequest, NextResponse } from "next/server";
import { getCampaigns } from "@/server/queries";
import { createCampaign } from "@/server/actions/campaigns";

export async function GET() { return NextResponse.json(await getCampaigns()); }
export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => null);
  const res = await createCampaign(body);
  return NextResponse.json(res, { status: res.ok ? 201 : 400 });
}
