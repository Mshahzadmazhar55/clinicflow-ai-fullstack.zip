import { NextRequest, NextResponse } from "next/server";
import { getPatients } from "@/server/queries";
import { createPatient } from "@/server/actions/patients";

export async function GET(req: NextRequest) {
  const sp = req.nextUrl.searchParams;
  const data = await getPatients({
    q: sp.get("q") ?? "", status: sp.get("status") ?? "all",
    page: Number(sp.get("page") ?? 1), pageSize: Number(sp.get("pageSize") ?? 8),
  });
  return NextResponse.json(data);
}

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => null);
  const res = await createPatient(body);
  return NextResponse.json(res, { status: res.ok ? 201 : 400 });
}
