import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getClinicId } from "@/lib/tenant";
import { updatePatient, deletePatient } from "@/server/actions/patients";

export async function GET(_req: NextRequest, { params }: { params: { id: string } }) {
  const clinicId = await getClinicId();
  const patient = await db.patient.findFirst({ where: { id: params.id, clinicId } });
  if (!patient) return NextResponse.json({ error: "Not found" }, { status: 404 });
  return NextResponse.json(patient);
}

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  const body = await req.json().catch(() => null);
  const res = await updatePatient(params.id, body);
  return NextResponse.json(res, { status: res.ok ? 200 : 400 });
}

export async function DELETE(_req: NextRequest, { params }: { params: { id: string } }) {
  const res = await deletePatient(params.id);
  return NextResponse.json(res, { status: res.ok ? 200 : 400 });
}
