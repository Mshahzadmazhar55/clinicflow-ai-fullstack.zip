import { NextRequest, NextResponse } from "next/server";
import { getCalendar } from "@/server/queries";
import { createAppointment } from "@/server/actions/appointments";

export async function GET() { return NextResponse.json(await getCalendar()); }
export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => null);
  const res = await createAppointment(body);
  return NextResponse.json(res, { status: res.ok ? 201 : 400 });
}
