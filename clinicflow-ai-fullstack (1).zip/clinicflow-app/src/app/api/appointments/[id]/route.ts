import { NextRequest, NextResponse } from "next/server";
import { updateAppointmentStatus, deleteAppointment } from "@/server/actions/appointments";

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  const body = await req.json().catch(() => ({}));
  const res = await updateAppointmentStatus(params.id, body?.status);
  return NextResponse.json(res, { status: res.ok ? 200 : 400 });
}
export async function DELETE(_req: NextRequest, { params }: { params: { id: string } }) {
  const res = await deleteAppointment(params.id);
  return NextResponse.json(res, { status: res.ok ? 200 : 400 });
}
