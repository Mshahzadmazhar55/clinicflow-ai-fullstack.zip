import { NextRequest, NextResponse } from "next/server";
import { getBilling } from "@/server/queries";
import { createInvoice } from "@/server/actions/invoices";

export async function GET() { return NextResponse.json(await getBilling()); }
export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => null);
  const res = await createInvoice(body);
  return NextResponse.json(res, { status: res.ok ? 201 : 400 });
}
