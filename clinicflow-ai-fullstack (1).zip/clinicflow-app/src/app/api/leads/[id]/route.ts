import { NextRequest, NextResponse } from "next/server";
import { moveLead, deleteLead } from "@/server/actions/leads";

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  const body = await req.json().catch(() => ({}));
  const res = await moveLead({ id: params.id, stage: body?.stage });
  return NextResponse.json(res, { status: res.ok ? 200 : 400 });
}
export async function DELETE(_req: NextRequest, { params }: { params: { id: string } }) {
  const res = await deleteLead(params.id);
  return NextResponse.json(res, { status: res.ok ? 200 : 400 });
}
