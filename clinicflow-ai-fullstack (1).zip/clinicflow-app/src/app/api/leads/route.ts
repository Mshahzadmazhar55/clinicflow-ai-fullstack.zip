import { NextRequest, NextResponse } from "next/server";
import { getLeadBoard } from "@/server/queries";
import { createLead } from "@/server/actions/leads";

export async function GET() { return NextResponse.json(await getLeadBoard()); }
export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => null);
  const res = await createLead(body);
  return NextResponse.json(res, { status: res.ok ? 201 : 400 });
}
