import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// Meta WhatsApp Cloud API webhook verification (GET)
export async function GET(req: NextRequest) {
  const sp = req.nextUrl.searchParams;
  const mode = sp.get("hub.mode");
  const token = sp.get("hub.verify_token");
  const challenge = sp.get("hub.challenge");
  if (mode === "subscribe" && token === process.env.WHATSAPP_VERIFY_TOKEN) {
    return new NextResponse(challenge ?? "", { status: 200 });
  }
  return new NextResponse("Forbidden", { status: 403 });
}

// Inbound messages (POST). Persists the message and, when AI is enabled,
// generates a reply. Replies are stubbed when OPENAI_API_KEY is absent so the
// loop works end-to-end in development.
export async function POST(req: NextRequest) {
  const payload = await req.json().catch(() => null);
  try {
    const value = payload?.entry?.[0]?.changes?.[0]?.value;
    const msg = value?.messages?.[0];
    const contact = value?.contacts?.[0];
    if (!msg) return NextResponse.json({ ignored: true });

    const phone = msg.from as string;
    const text = msg.text?.body ?? "";
    const name = contact?.profile?.name ?? phone;

    // Resolve clinic by the receiving phone number id, else first clinic (dev)
    const phoneNumberId = value?.metadata?.phone_number_id as string | undefined;
    const config = phoneNumberId
      ? await db.whatsAppConfig.findFirst({ where: { phoneNumberId } })
      : null;
    const clinic = config
      ? await db.clinic.findUnique({ where: { id: config.clinicId } })
      : await db.clinic.findFirst({ orderBy: { createdAt: "asc" } });
    if (!clinic) return NextResponse.json({ error: "No clinic" }, { status: 404 });

    const convo = await db.conversation.upsert({
      where: { id: (await db.conversation.findFirst({ where: { clinicId: clinic.id, phone } }))?.id ?? "____none____" },
      create: { clinicId: clinic.id, contactName: name, phone, status: "AI", unread: 1, lastAt: new Date() },
      update: { unread: { increment: 1 }, lastAt: new Date() },
    }).catch(async () => {
      return db.conversation.create({ data: { clinicId: clinic.id, contactName: name, phone, status: "AI", unread: 1 } });
    });

    await db.message.create({ data: { conversationId: convo.id, sender: "PATIENT", body: text } });

    const wa = await db.whatsAppConfig.findUnique({ where: { clinicId: clinic.id } });
    if (wa?.aiEnabled) {
      const reply = await generateReply(text);
      await db.message.create({ data: { conversationId: convo.id, sender: "AI", body: reply } });
      // sendWhatsApp(phone, reply) — wired to Meta API in production
    }
    return NextResponse.json({ ok: true });
  } catch (e) {
    return NextResponse.json({ error: "Bad payload" }, { status: 400 });
  }
}

async function generateReply(text: string): Promise<string> {
  if (!process.env.OPENAI_API_KEY) {
    return "Halo Kak! 😊 Terima kasih sudah menghubungi kami. Tim kami akan segera membantu. Mau saya bantu cek jadwal?";
  }
  const res = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${process.env.OPENAI_API_KEY}` },
    body: JSON.stringify({
      model: "gpt-4o-mini",
      messages: [
        { role: "system", content: "You are a warm Indonesian clinic receptionist. Reply briefly in the patient's language. Never give medical diagnoses." },
        { role: "user", content: text },
      ],
    }),
  });
  const data = await res.json();
  return data?.choices?.[0]?.message?.content ?? "Maaf, ada kendala. Tim kami akan membantu Kakak.";
}
