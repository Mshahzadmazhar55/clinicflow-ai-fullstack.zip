import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// Stripe subscription webhook. Signature verification is enabled in production
// (STRIPE_WEBHOOK_SECRET). The handler maps subscription lifecycle to plan state.
export async function POST(req: NextRequest) {
  const event = await req.json().catch(() => null);
  if (!event?.type) return NextResponse.json({ error: "Bad event" }, { status: 400 });

  try {
    switch (event.type) {
      case "checkout.session.completed":
      case "customer.subscription.updated": {
        const sub = event.data?.object;
        const customerId = sub?.customer as string | undefined;
        if (customerId) {
          const subscription = await db.subscription.findFirst({ where: { stripeCustomerId: customerId } });
          if (subscription) {
            await db.subscription.update({
              where: { id: subscription.id },
              data: { status: "ACTIVE", stripeSubId: sub?.id ?? subscription.stripeSubId },
            });
          }
        }
        break;
      }
      case "customer.subscription.deleted": {
        const sub = event.data?.object;
        const subscription = await db.subscription.findFirst({ where: { stripeSubId: sub?.id } });
        if (subscription) await db.subscription.update({ where: { id: subscription.id }, data: { status: "CANCELED" } });
        break;
      }
    }
    return NextResponse.json({ received: true });
  } catch {
    return NextResponse.json({ error: "Handler error" }, { status: 500 });
  }
}
