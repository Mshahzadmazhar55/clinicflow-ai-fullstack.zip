"use server";
import { revalidatePath } from "next/cache";
import { db } from "@/lib/db";
import { getClinicId, getCurrentUser, audit } from "@/lib/tenant";
import { inviteSchema, updateMemberSchema } from "@/lib/validations/team";
import { atLeast } from "@/lib/constants";
import type { ActionResult } from "./patients";

export async function inviteMember(input: unknown): Promise<ActionResult> {
  const me = await getCurrentUser();
  if (!atLeast(me.role, "MANAGER")) return { ok: false, error: "You don't have permission to invite members." };
  const parsed = inviteSchema.safeParse(input);
  if (!parsed.success) return { ok: false, fieldErrors: parsed.error.flatten().fieldErrors };
  const d = parsed.data;
  const exists = await db.user.findUnique({ where: { email: d.email } });
  if (exists) return { ok: false, error: "A user with that email already exists." };
  const u = await db.user.create({
    data: { clinicId: me.clinicId, email: d.email, name: d.name || d.email.split("@")[0], role: d.role, status: "INVITED" },
  });
  await audit("invite", "User", u.id, { email: d.email, role: d.role });
  revalidatePath("/team");
  return { ok: true, id: u.id };
}

export async function updateMember(input: unknown): Promise<ActionResult> {
  const me = await getCurrentUser();
  if (!atLeast(me.role, "MANAGER")) return { ok: false, error: "You don't have permission." };
  const parsed = updateMemberSchema.safeParse(input);
  if (!parsed.success) return { ok: false, error: "Invalid input" };
  const clinicId = await getClinicId();
  const member = await db.user.findFirst({ where: { id: parsed.data.id, clinicId } });
  if (!member) return { ok: false, error: "Member not found" };
  await db.user.update({ where: { id: parsed.data.id }, data: { role: parsed.data.role, status: parsed.data.status } });
  await audit("update", "User", parsed.data.id);
  revalidatePath("/team");
  return { ok: true };
}

export async function removeMember(id: string): Promise<ActionResult> {
  const me = await getCurrentUser();
  if (!atLeast(me.role, "ADMIN")) return { ok: false, error: "Only admins can remove members." };
  if (id === me.id) return { ok: false, error: "You can't remove yourself." };
  const member = await db.user.findFirst({ where: { id, clinicId: me.clinicId } });
  if (!member) return { ok: false, error: "Member not found" };
  await db.user.delete({ where: { id } });
  await audit("remove", "User", id);
  revalidatePath("/team");
  return { ok: true };
}
