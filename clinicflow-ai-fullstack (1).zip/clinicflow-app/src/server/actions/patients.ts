"use server";
import { revalidatePath } from "next/cache";
import { db } from "@/lib/db";
import { getClinicId, audit } from "@/lib/tenant";
import { patientSchema } from "@/lib/validations/patient";

export type ActionResult = { ok: boolean; error?: string; fieldErrors?: Record<string, string[]>; id?: string };

export async function createPatient(input: unknown): Promise<ActionResult> {
  const parsed = patientSchema.safeParse(input);
  if (!parsed.success) return { ok: false, fieldErrors: parsed.error.flatten().fieldErrors };
  const clinicId = await getClinicId();
  const d = parsed.data;
  const p = await db.patient.create({
    data: {
      clinicId, fullName: d.fullName, phone: d.phone, email: d.email || null,
      gender: d.gender, status: d.status, notes: d.notes || null, tagsJson: JSON.stringify(d.tags ?? []),
    },
  });
  await audit("create", "Patient", p.id, { name: p.fullName });
  revalidatePath("/patients");
  return { ok: true, id: p.id };
}

export async function updatePatient(id: string, input: unknown): Promise<ActionResult> {
  const parsed = patientSchema.safeParse(input);
  if (!parsed.success) return { ok: false, fieldErrors: parsed.error.flatten().fieldErrors };
  const clinicId = await getClinicId();
  const existing = await db.patient.findFirst({ where: { id, clinicId } });
  if (!existing) return { ok: false, error: "Patient not found" };
  const d = parsed.data;
  await db.patient.update({
    where: { id },
    data: { fullName: d.fullName, phone: d.phone, email: d.email || null, gender: d.gender, status: d.status, notes: d.notes || null, tagsJson: JSON.stringify(d.tags ?? []) },
  });
  await audit("update", "Patient", id);
  revalidatePath("/patients");
  return { ok: true, id };
}

export async function deletePatient(id: string): Promise<ActionResult> {
  const clinicId = await getClinicId();
  const existing = await db.patient.findFirst({ where: { id, clinicId } });
  if (!existing) return { ok: false, error: "Patient not found" };
  await db.patient.delete({ where: { id } });
  await audit("delete", "Patient", id);
  revalidatePath("/patients");
  return { ok: true };
}
