"use server";
import { revalidatePath } from "next/cache";
import { db } from "@/lib/db";
import { getClinicId, audit } from "@/lib/tenant";
import { appointmentSchema } from "@/lib/validations/appointment";
import type { ActionResult } from "./patients";

export async function createAppointment(input: unknown): Promise<ActionResult> {
  const parsed = appointmentSchema.safeParse(input);
  if (!parsed.success) return { ok: false, fieldErrors: parsed.error.flatten().fieldErrors };
  const clinicId = await getClinicId();
  const d = parsed.data;
  const start = new Date(d.startAt);
  if (isNaN(start.getTime())) return { ok: false, error: "Invalid start time" };
  const end = new Date(start.getTime() + d.durationMin * 60000);

  // double-booking guard for the same practitioner
  if (d.practitionerId) {
    const clash = await db.appointment.findFirst({
      where: { clinicId, practitionerId: d.practitionerId, status: { notIn: ["CANCELED", "NO_SHOW"] }, startAt: { lt: end }, endAt: { gt: start } },
    });
    if (clash) return { ok: false, error: "That practitioner already has an appointment in this slot." };
  }
  const appt = await db.appointment.create({
    data: { clinicId, patientId: d.patientId, serviceId: d.serviceId || null, practitionerId: d.practitionerId || null, startAt: start, endAt: end, status: d.status, notes: d.notes || null },
  });
  await db.patient.update({ where: { id: d.patientId }, data: { lastVisitAt: start, status: "ACTIVE" } });
  await audit("create", "Appointment", appt.id);
  revalidatePath("/calendar"); revalidatePath("/dashboard");
  return { ok: true, id: appt.id };
}

export async function updateAppointmentStatus(id: string, status: string): Promise<ActionResult> {
  const clinicId = await getClinicId();
  const existing = await db.appointment.findFirst({ where: { id, clinicId } });
  if (!existing) return { ok: false, error: "Appointment not found" };
  await db.appointment.update({ where: { id }, data: { status } });
  await audit("status", "Appointment", id, { status });
  revalidatePath("/calendar"); revalidatePath("/dashboard");
  return { ok: true };
}

export async function deleteAppointment(id: string): Promise<ActionResult> {
  const clinicId = await getClinicId();
  const existing = await db.appointment.findFirst({ where: { id, clinicId } });
  if (!existing) return { ok: false, error: "Appointment not found" };
  await db.appointment.delete({ where: { id } });
  revalidatePath("/calendar");
  return { ok: true };
}
