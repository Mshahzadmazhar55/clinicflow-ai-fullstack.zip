"use server";
import { revalidatePath } from "next/cache";
import { db } from "@/lib/db";
import { getClinicId, audit } from "@/lib/tenant";
import { invoiceSchema } from "@/lib/validations/invoice";
import type { ActionResult } from "./patients";

export async function createInvoice(input: unknown): Promise<ActionResult> {
  const parsed = invoiceSchema.safeParse(input);
  if (!parsed.success) return { ok: false, fieldErrors: parsed.error.flatten().fieldErrors };
  const clinicId = await getClinicId();
  const d = parsed.data;
  const count = await db.invoice.count({ where: { clinicId } });
  const number = `INV-${new Date().getFullYear()}-${String(count + 1).padStart(4, "0")}`;
  const inv = await db.invoice.create({
    data: {
      clinicId, number, patientId: d.patientId || null, amountCents: Math.round(d.amount * 100),
      status: d.status, method: d.method || null, paidAt: d.status === "PAID" ? new Date() : null,
    },
  });
  if (d.status === "PAID" && d.patientId) {
    await db.patient.update({ where: { id: d.patientId }, data: { totalSpent: { increment: Math.round(d.amount * 100) } } });
  }
  await audit("create", "Invoice", inv.id, { number });
  revalidatePath("/billing");
  return { ok: true, id: inv.id };
}

export async function markInvoicePaid(id: string): Promise<ActionResult> {
  const clinicId = await getClinicId();
  const inv = await db.invoice.findFirst({ where: { id, clinicId } });
  if (!inv) return { ok: false, error: "Invoice not found" };
  await db.invoice.update({ where: { id }, data: { status: "PAID", paidAt: new Date() } });
  if (inv.patientId) await db.patient.update({ where: { id: inv.patientId }, data: { totalSpent: { increment: inv.amountCents } } });
  await audit("paid", "Invoice", id);
  revalidatePath("/billing");
  return { ok: true };
}
