"use server";
import { revalidatePath } from "next/cache";
import { db } from "@/lib/db";
import { getClinicId, audit } from "@/lib/tenant";
import { leadSchema, leadStageSchema } from "@/lib/validations/lead";
import type { ActionResult } from "./patients";

export async function createLead(input: unknown): Promise<ActionResult> {
  const parsed = leadSchema.safeParse(input);
  if (!parsed.success) return { ok: false, fieldErrors: parsed.error.flatten().fieldErrors };
  const clinicId = await getClinicId();
  const d = parsed.data;
  const lead = await db.lead.create({
    data: { clinicId, name: d.name, phone: d.phone || null, source: d.source, interest: d.interest || null, valueCents: Math.round(d.value * 100), stage: d.stage },
  });
  await audit("create", "Lead", lead.id, { name: lead.name });
  revalidatePath("/crm");
  return { ok: true, id: lead.id };
}

export async function moveLead(input: unknown): Promise<ActionResult> {
  const parsed = leadStageSchema.safeParse(input);
  if (!parsed.success) return { ok: false, error: "Invalid stage" };
  const clinicId = await getClinicId();
  const existing = await db.lead.findFirst({ where: { id: parsed.data.id, clinicId } });
  if (!existing) return { ok: false, error: "Lead not found" };
  await db.lead.update({ where: { id: parsed.data.id }, data: { stage: parsed.data.stage } });
  await audit("move", "Lead", parsed.data.id, { stage: parsed.data.stage });
  revalidatePath("/crm");
  return { ok: true };
}

export async function deleteLead(id: string): Promise<ActionResult> {
  const clinicId = await getClinicId();
  const existing = await db.lead.findFirst({ where: { id, clinicId } });
  if (!existing) return { ok: false, error: "Lead not found" };
  await db.lead.delete({ where: { id } });
  revalidatePath("/crm");
  return { ok: true };
}
