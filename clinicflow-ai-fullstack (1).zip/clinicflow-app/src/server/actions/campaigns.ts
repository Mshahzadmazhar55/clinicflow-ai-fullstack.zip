"use server";
import { revalidatePath } from "next/cache";
import { db } from "@/lib/db";
import { getClinicId, audit } from "@/lib/tenant";
import { campaignSchema } from "@/lib/validations/campaign";
import type { ActionResult } from "./patients";

export async function createCampaign(input: unknown): Promise<ActionResult> {
  const parsed = campaignSchema.safeParse(input);
  if (!parsed.success) return { ok: false, fieldErrors: parsed.error.flatten().fieldErrors };
  const clinicId = await getClinicId();
  const d = parsed.data;
  const segment = d.segmentId ? await db.segment.findFirst({ where: { id: d.segmentId, clinicId } }) : null;
  const status = d.scheduledAt ? "SCHEDULED" : d.status;
  const c = await db.campaign.create({
    data: {
      clinicId, name: d.name, channel: d.channel, body: d.body, status,
      segmentId: segment?.id ?? null, recipients: segment?.count ?? 0,
      scheduledAt: d.scheduledAt ? new Date(d.scheduledAt) : null,
    },
  });
  await audit("create", "Campaign", c.id, { name: c.name });
  revalidatePath("/marketing");
  return { ok: true, id: c.id };
}

export async function sendCampaign(id: string): Promise<ActionResult> {
  const clinicId = await getClinicId();
  const c = await db.campaign.findFirst({ where: { id, clinicId } });
  if (!c) return { ok: false, error: "Campaign not found" };
  await db.campaign.update({ where: { id }, data: { status: "SENT", sentAt: new Date(), openRate: 60 + Math.floor(Math.random() * 20) } });
  await audit("send", "Campaign", id);
  revalidatePath("/marketing");
  return { ok: true };
}

export async function deleteCampaign(id: string): Promise<ActionResult> {
  const clinicId = await getClinicId();
  const c = await db.campaign.findFirst({ where: { id, clinicId } });
  if (!c) return { ok: false, error: "Campaign not found" };
  await db.campaign.delete({ where: { id } });
  revalidatePath("/marketing");
  return { ok: true };
}
