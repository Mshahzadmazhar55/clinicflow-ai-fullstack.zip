"use server";
import { revalidatePath } from "next/cache";
import { db } from "@/lib/db";
import { getClinicId, getCurrentUser, audit } from "@/lib/tenant";
import { clinicSchema, aiSchema } from "@/lib/validations/settings";
import { atLeast } from "@/lib/constants";
import type { ActionResult } from "./patients";

export async function updateClinic(input: unknown): Promise<ActionResult> {
  const me = await getCurrentUser();
  if (!atLeast(me.role, "MANAGER")) return { ok: false, error: "You don't have permission." };
  const parsed = clinicSchema.safeParse(input);
  if (!parsed.success) return { ok: false, fieldErrors: parsed.error.flatten().fieldErrors };
  const clinicId = await getClinicId();
  const d = parsed.data;
  await db.clinic.update({ where: { id: clinicId }, data: { name: d.name, phone: d.phone || null, city: d.city || null, address: d.address || null, timezone: d.timezone } });
  await audit("update", "Clinic", clinicId);
  revalidatePath("/settings");
  return { ok: true };
}

export async function updateAi(input: unknown): Promise<ActionResult> {
  const me = await getCurrentUser();
  if (!atLeast(me.role, "MANAGER")) return { ok: false, error: "You don't have permission." };
  const parsed = aiSchema.safeParse(input);
  if (!parsed.success) return { ok: false, fieldErrors: parsed.error.flatten().fieldErrors };
  const clinicId = await getClinicId();
  const d = parsed.data;
  await db.whatsAppConfig.upsert({
    where: { clinicId },
    create: { clinicId, aiEnabled: d.aiEnabled, aiLanguage: d.aiLanguage, aiPersona: d.aiPersona, remindersOn: d.remindersOn, followupsOn: d.followupsOn },
    update: { aiEnabled: d.aiEnabled, aiLanguage: d.aiLanguage, aiPersona: d.aiPersona, remindersOn: d.remindersOn, followupsOn: d.followupsOn },
  });
  await audit("update", "WhatsAppConfig", clinicId);
  revalidatePath("/settings");
  return { ok: true };
}
