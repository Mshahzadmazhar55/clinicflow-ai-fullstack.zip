import "server-only";
import { db } from "@/lib/db";
import { getClinicId } from "@/lib/tenant";
import { startOfDay, endOfDay, subMonths, format } from "date-fns";

export async function getDashboard() {
  const clinicId = await getClinicId();
  const now = new Date();
  const [todayCount, patients, leads, sub, todays, recentConvos, sixMo] = await Promise.all([
    db.appointment.count({ where: { clinicId, startAt: { gte: startOfDay(now), lte: endOfDay(now) } } }),
    db.patient.count({ where: { clinicId } }),
    db.lead.count({ where: { clinicId, stage: { in: ["NEW", "CONTACTED", "QUALIFIED", "CONSULT"] } } }),
    db.subscription.findUnique({ where: { clinicId } }),
    db.appointment.findMany({
      where: { clinicId, startAt: { gte: startOfDay(now), lte: endOfDay(now) } },
      include: { patient: true, service: true, practitioner: true }, orderBy: { startAt: "asc" }, take: 6,
    }),
    db.conversation.findMany({ where: { clinicId }, orderBy: { lastAt: "desc" }, take: 5 }),
    db.invoice.findMany({ where: { clinicId, status: "PAID", paidAt: { gte: subMonths(now, 6) } }, select: { amountCents: true, paidAt: true } }),
  ]);

  const months: { month: string; revenue: number }[] = [];
  for (let i = 5; i >= 0; i--) {
    const d = subMonths(now, i);
    const key = format(d, "MMM");
    const revenue = sixMo
      .filter((inv) => inv.paidAt && format(inv.paidAt, "MMM yyyy") === format(d, "MMM yyyy"))
      .reduce((s, inv) => s + inv.amountCents, 0);
    months.push({ month: key, revenue: Math.round(revenue / 1_000_000) });
  }
  const revToday = await db.invoice.aggregate({
    where: { clinicId, status: "PAID", paidAt: { gte: startOfDay(now), lte: endOfDay(now) } }, _sum: { amountCents: true },
  });
  return {
    stats: { todayCount, patients, leads, revenueToday: revToday._sum.amountCents ?? 0 },
    sub, todays, recentConvos, revenueSeries: months,
  };
}

export type PatientFilter = { q?: string; status?: string; page?: number; pageSize?: number };
export async function getPatients({ q = "", status = "all", page = 1, pageSize = 8 }: PatientFilter) {
  const clinicId = await getClinicId();
  const where: any = { clinicId };
  if (status !== "all") where.status = status.toUpperCase();
  if (q) where.OR = [{ fullName: { contains: q } }, { phone: { contains: q } }, { email: { contains: q } }];
  const [total, rows] = await Promise.all([
    db.patient.count({ where }),
    db.patient.findMany({ where, orderBy: { createdAt: "desc" }, skip: (page - 1) * pageSize, take: pageSize }),
  ]);
  return { total, rows, page, pageCount: Math.max(1, Math.ceil(total / pageSize)) };
}

export async function getPatientOptions() {
  const clinicId = await getClinicId();
  return db.patient.findMany({ where: { clinicId }, select: { id: true, fullName: true }, orderBy: { fullName: "asc" } });
}

export async function getLeadBoard() {
  const clinicId = await getClinicId();
  const leads = await db.lead.findMany({ where: { clinicId }, orderBy: { createdAt: "desc" } });
  return leads;
}

export async function getCalendar() {
  const clinicId = await getClinicId();
  const [appts, practitioners] = await Promise.all([
    db.appointment.findMany({ where: { clinicId }, include: { patient: true, service: true, practitioner: true }, orderBy: { startAt: "asc" } }),
    db.practitioner.findMany({ where: { clinicId, active: true } }),
  ]);
  return { appts, practitioners };
}

export async function getConversations() {
  const clinicId = await getClinicId();
  return db.conversation.findMany({
    where: { clinicId }, include: { messages: { orderBy: { createdAt: "asc" } } }, orderBy: { lastAt: "desc" },
  });
}

export async function getCampaigns() {
  const clinicId = await getClinicId();
  const [campaigns, segments] = await Promise.all([
    db.campaign.findMany({ where: { clinicId }, include: { segment: true }, orderBy: { createdAt: "desc" } }),
    db.segment.findMany({ where: { clinicId }, orderBy: { name: "asc" } }),
  ]);
  return { campaigns, segments };
}

export async function getBilling() {
  const clinicId = await getClinicId();
  const [sub, invoices, seats] = await Promise.all([
    db.subscription.findUnique({ where: { clinicId } }),
    db.invoice.findMany({ where: { clinicId }, include: { patient: true }, orderBy: { issuedAt: "desc" }, take: 20 }),
    db.user.count({ where: { clinicId, status: "ACTIVE" } }),
  ]);
  const outstanding = invoices.filter((i) => i.status === "OVERDUE" || i.status === "SENT").reduce((s, i) => s + i.amountCents, 0);
  return { sub, invoices, seats, outstanding };
}

export async function getTeam() {
  const clinicId = await getClinicId();
  return db.user.findMany({ where: { clinicId }, orderBy: { createdAt: "asc" } });
}

export async function getSettings() {
  const clinicId = await getClinicId();
  const [clinic, wa] = await Promise.all([
    db.clinic.findUnique({ where: { id: clinicId } }),
    db.whatsAppConfig.findUnique({ where: { clinicId } }),
  ]);
  return { clinic, wa };
}

export async function getAnalytics() {
  const clinicId = await getClinicId();
  const now = new Date();
  const paid = await db.invoice.findMany({ where: { clinicId, status: "PAID", paidAt: { gte: subMonths(now, 6) } }, select: { amountCents: true, paidAt: true } });
  const series: { month: string; revenue: number; appointments: number }[] = [];
  for (let i = 5; i >= 0; i--) {
    const d = subMonths(now, i);
    const revenue = paid.filter((p) => p.paidAt && format(p.paidAt, "MMM yyyy") === format(d, "MMM yyyy")).reduce((s, p) => s + p.amountCents, 0);
    const appointments = await db.appointment.count({
      where: { clinicId, startAt: { gte: startOfDay(subMonths(now, i)), lte: endOfDay(subMonths(now, i - 1 < 0 ? 0 : i)) } },
    });
    series.push({ month: format(d, "MMM"), revenue: Math.round(revenue / 1_000_000), appointments });
  }
  const totalRevenue = paid.reduce((s, p) => s + p.amountCents, 0);
  const practitioners = await db.practitioner.findMany({
    where: { clinicId }, include: { _count: { select: { appointments: true } } },
  });
  return { series, totalRevenue, practitioners };
}
