import "next-auth";
declare module "next-auth" {
  interface Session { user: { id: string; name?: string | null; email?: string | null; role: string; clinicId: string } }
}
declare module "next-auth/jwt" {
  interface JWT { uid?: string; role?: string; clinicId?: string }
}
