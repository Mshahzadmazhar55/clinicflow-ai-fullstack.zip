import { z } from "zod";
import { CAMPAIGN_CHANNELS, CAMPAIGN_STATUS } from "@/lib/constants";

export const campaignSchema = z.object({
  name: z.string().min(2, "Name is required").max(120),
  channel: z.enum(CAMPAIGN_CHANNELS).default("WHATSAPP"),
  segmentId: z.string().optional().or(z.literal("")),
  body: z.string().min(1, "Message body is required").max(2000),
  status: z.enum(CAMPAIGN_STATUS).default("DRAFT"),
  scheduledAt: z.string().optional().or(z.literal("")),
});
export type CampaignInput = z.infer<typeof campaignSchema>;
