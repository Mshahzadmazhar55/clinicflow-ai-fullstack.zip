import { z } from "zod";
import { ROLES } from "@/lib/constants";

export const inviteSchema = z.object({
  name: z.string().min(2, "Name is required").max(120).optional().or(z.literal("")),
  email: z.string().email("Enter a valid email"),
  role: z.enum(ROLES).default("RECEPTIONIST"),
});
export type InviteInput = z.infer<typeof inviteSchema>;

export const updateMemberSchema = z.object({
  id: z.string(),
  role: z.enum(ROLES).optional(),
  status: z.enum(["ACTIVE", "INVITED", "DISABLED"]).optional(),
});
