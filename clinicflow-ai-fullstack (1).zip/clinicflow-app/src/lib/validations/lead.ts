import { z } from "zod";
import { LEAD_SOURCES, LEAD_STAGES } from "@/lib/constants";

export const leadSchema = z.object({
  name: z.string().min(2, "Name is required").max(120),
  phone: z.string().max(30).optional().or(z.literal("")),
  source: z.enum(LEAD_SOURCES).default("WHATSAPP"),
  interest: z.string().max(120).optional().or(z.literal("")),
  value: z.coerce.number().min(0, "Must be 0 or more").default(0),
  stage: z.enum(LEAD_STAGES).default("NEW"),
});
export type LeadInput = z.infer<typeof leadSchema>;

export const leadStageSchema = z.object({ id: z.string(), stage: z.enum(LEAD_STAGES) });
