import { z } from "zod";

export const clinicSchema = z.object({
  name: z.string().min(2, "Clinic name is required").max(160),
  phone: z.string().max(30).optional().or(z.literal("")),
  city: z.string().max(80).optional().or(z.literal("")),
  address: z.string().max(240).optional().or(z.literal("")),
  timezone: z.string().default("Asia/Jakarta"),
});
export type ClinicInput = z.infer<typeof clinicSchema>;

export const aiSchema = z.object({
  aiEnabled: z.boolean().default(true),
  aiLanguage: z.enum(["auto", "id", "en"]).default("auto"),
  aiPersona: z.string().max(1000),
  remindersOn: z.boolean().default(true),
  followupsOn: z.boolean().default(true),
});
export type AiInput = z.infer<typeof aiSchema>;
