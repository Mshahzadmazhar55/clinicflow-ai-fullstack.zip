import { z } from "zod";
import { APPT_STATUS } from "@/lib/constants";

export const appointmentSchema = z.object({
  patientId: z.string().min(1, "Select a patient"),
  serviceId: z.string().optional().or(z.literal("")),
  practitionerId: z.string().optional().or(z.literal("")),
  startAt: z.string().min(1, "Pick a start time"),
  durationMin: z.coerce.number().int().min(5).max(480).default(30),
  status: z.enum(APPT_STATUS).default("CONFIRMED"),
  notes: z.string().max(1000).optional().or(z.literal("")),
});
export type AppointmentInput = z.infer<typeof appointmentSchema>;
