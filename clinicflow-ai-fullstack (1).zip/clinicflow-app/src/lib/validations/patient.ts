import { z } from "zod";
import { PATIENT_STATUS } from "@/lib/constants";

export const patientSchema = z.object({
  fullName: z.string().min(2, "Name must be at least 2 characters").max(120),
  phone: z.string().min(6, "Enter a valid phone number").max(30),
  email: z.string().email("Invalid email").optional().or(z.literal("")),
  gender: z.enum(["FEMALE", "MALE", "OTHER"]).optional(),
  status: z.enum(PATIENT_STATUS).default("NEW"),
  notes: z.string().max(2000).optional().or(z.literal("")),
  tags: z.array(z.string()).default([]),
});
export type PatientInput = z.infer<typeof patientSchema>;
