import { z } from "zod";
import { INVOICE_STATUS } from "@/lib/constants";

export const invoiceSchema = z.object({
  patientId: z.string().optional().or(z.literal("")),
  amount: z.coerce.number().min(0, "Amount must be 0 or more"),
  status: z.enum(INVOICE_STATUS).default("DRAFT"),
  method: z.string().max(40).optional().or(z.literal("")),
});
export type InvoiceInput = z.infer<typeof invoiceSchema>;
