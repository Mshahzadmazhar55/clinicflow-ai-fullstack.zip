import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { db } from "@/lib/db";

export type CurrentUser = { id: string; name: string; email: string; role: string; clinicId: string };

/**
 * Resolves the acting user + clinic. Uses the NextAuth session when present;
 * for local/demo use it falls back to the seeded demo clinic's admin so every
 * screen works immediately after `db:seed`.
 */
export async function getCurrentUser(): Promise<CurrentUser> {
  const session = await getServerSession(authOptions);
  const sUser = session?.user as any;
  if (sUser?.id && sUser?.clinicId) {
    return { id: sUser.id, name: sUser.name, email: sUser.email, role: sUser.role, clinicId: sUser.clinicId };
  }
  const fallback = await db.user.findFirst({ where: { role: "ADMIN" }, orderBy: { createdAt: "asc" } });
  if (!fallback) throw new Error("No users seeded. Run `npm run db:seed`.");
  return { id: fallback.id, name: fallback.name, email: fallback.email, role: fallback.role, clinicId: fallback.clinicId };
}

export async function getClinicId(): Promise<string> {
  return (await getCurrentUser()).clinicId;
}

export async function audit(action: string, entity: string, entityId?: string, meta: Record<string, unknown> = {}) {
  const u = await getCurrentUser();
  await db.auditLog.create({
    data: { clinicId: u.clinicId, userId: u.id, action, entity, entityId, metaJson: JSON.stringify(meta) },
  });
}
