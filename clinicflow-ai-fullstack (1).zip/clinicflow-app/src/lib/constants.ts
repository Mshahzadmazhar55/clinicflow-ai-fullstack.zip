export const ROLES = ["ADMIN", "MANAGER", "DOCTOR", "RECEPTIONIST", "STAFF"] as const;
export type Role = (typeof ROLES)[number];
export const ROLE_RANK: Record<Role, number> = { STAFF: 1, RECEPTIONIST: 2, DOCTOR: 3, MANAGER: 4, ADMIN: 5 };
export function atLeast(role: string, min: Role) {
  return (ROLE_RANK[role as Role] ?? 0) >= ROLE_RANK[min];
}

export const PATIENT_STATUS = ["NEW", "ACTIVE", "INACTIVE"] as const;
export const APPT_STATUS = ["REQUESTED", "CONFIRMED", "CHECKED_IN", "COMPLETED", "CANCELED", "NO_SHOW"] as const;
export const LEAD_STAGES = ["NEW", "CONTACTED", "QUALIFIED", "CONSULT", "CONVERTED", "LOST"] as const;
export const LEAD_SOURCES = ["WHATSAPP", "INSTAGRAM", "WEBSITE", "GOOGLE", "TIKTOK", "REFERRAL", "WALK_IN"] as const;
export const CAMPAIGN_CHANNELS = ["WHATSAPP", "EMAIL"] as const;
export const CAMPAIGN_STATUS = ["DRAFT", "SCHEDULED", "SENDING", "SENT"] as const;
export const INVOICE_STATUS = ["DRAFT", "SENT", "PAID", "OVERDUE", "VOID"] as const;

export const PLANS = [
  { tier: "STARTER", name: "Starter", priceCents: 29900000, seats: 5, patients: 1000, waMsgs: 2000, aiCredits: 1000,
    features: ["5 seats", "1,000 patients", "2,000 WA messages", "AI receptionist"] },
  { tier: "GROWTH", name: "Growth", priceCents: 79900000, seats: 15, patients: 5000, waMsgs: 10000, aiCredits: 5000,
    features: ["15 seats", "5,000 patients", "10,000 WA messages", "CRM + campaigns", "Analytics"] },
  { tier: "PRO", name: "Pro", priceCents: 199900000, seats: 50, patients: 25000, waMsgs: 50000, aiCredits: 25000,
    features: ["50 seats", "25,000 patients", "50,000 WA messages", "Multi-branch", "Priority support"] },
] as const;
