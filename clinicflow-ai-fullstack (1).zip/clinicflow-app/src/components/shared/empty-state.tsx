import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";

export function EmptyState({
  icon: Icon, title, description, actionLabel, onAction, className,
}: {
  icon: React.ElementType; title: string; description: string;
  actionLabel?: string; onAction?: () => void; className?: string;
}) {
  return (
    <div className={cn("flex flex-col items-center justify-center rounded-xl border border-dashed bg-card/50 px-6 py-16 text-center", className)}>
      <span className="flex h-12 w-12 items-center justify-center rounded-full bg-accent text-accent-foreground">
        <Icon className="h-6 w-6" />
      </span>
      <h3 className="mt-4 font-semibold">{title}</h3>
      <p className="mt-1 max-w-sm text-sm text-muted-foreground">{description}</p>
      {actionLabel && <Button className="mt-4" onClick={onAction}>{actionLabel}</Button>}
    </div>
  );
}
