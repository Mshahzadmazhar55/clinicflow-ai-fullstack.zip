import { ArrowDownRight, ArrowUpRight } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";

export function StatCard({
  label, value, delta, icon: Icon, hint,
}: { label: string; value: string; delta?: number; icon: React.ElementType; hint?: string }) {
  const up = (delta ?? 0) >= 0;
  return (
    <Card>
      <CardContent className="p-5">
        <div className="flex items-center justify-between">
          <span className="text-sm text-muted-foreground">{label}</span>
          <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-accent text-accent-foreground">
            <Icon className="h-4 w-4" />
          </span>
        </div>
        <div className="mt-3 text-2xl font-semibold tnum">{value}</div>
        <div className="mt-1 flex items-center gap-1 text-xs">
          {delta !== undefined && (
            <span className={cn("flex items-center gap-0.5 font-medium", up ? "text-success" : "text-destructive")}>
              {up ? <ArrowUpRight className="h-3 w-3" /> : <ArrowDownRight className="h-3 w-3" />}
              {Math.abs(delta)}%
            </span>
          )}
          <span className="text-muted-foreground">{hint ?? "vs last month"}</span>
        </div>
      </CardContent>
    </Card>
  );
}
