"use client";
import * as React from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { patientSchema, type PatientInput } from "@/lib/validations/patient";
import { createPatient, updatePatient } from "@/server/actions/patients";
import { Form, FormField, FormItem, FormLabel, FormControl, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select";

type Props = {
  defaults?: Partial<PatientInput> & { id?: string };
  onDone?: () => void;
};

export function PatientForm({ defaults, onDone }: Props) {
  const router = useRouter();
  const [pending, setPending] = React.useState(false);
  const form = useForm<PatientInput>({
    resolver: zodResolver(patientSchema),
    defaultValues: {
      fullName: defaults?.fullName ?? "", phone: defaults?.phone ?? "", email: defaults?.email ?? "",
      gender: defaults?.gender, status: defaults?.status ?? "NEW", notes: defaults?.notes ?? "",
      tags: defaults?.tags ?? [],
    },
  });
  const [tagsText, setTagsText] = React.useState((defaults?.tags ?? []).join(", "));

  async function onSubmit(values: PatientInput) {
    setPending(true);
    values.tags = tagsText.split(",").map((t) => t.trim()).filter(Boolean);
    const res = defaults?.id ? await updatePatient(defaults.id, values) : await createPatient(values);
    setPending(false);
    if (res.ok) {
      toast.success(defaults?.id ? "Patient updated" : "Patient added");
      router.refresh(); onDone?.();
    } else if (res.fieldErrors) {
      Object.entries(res.fieldErrors).forEach(([k, v]) => form.setError(k as any, { message: v?.[0] }));
    } else toast.error(res.error ?? "Something went wrong");
  }

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <FormField control={form.control} name="fullName" render={({ field }) => (
          <FormItem><FormLabel>Full name</FormLabel><FormControl><Input placeholder="Rina Wijaya" {...field} /></FormControl><FormMessage /></FormItem>
        )} />
        <div className="grid grid-cols-2 gap-3">
          <FormField control={form.control} name="phone" render={({ field }) => (
            <FormItem><FormLabel>Phone</FormLabel><FormControl><Input placeholder="+62 812…" {...field} /></FormControl><FormMessage /></FormItem>
          )} />
          <FormField control={form.control} name="email" render={({ field }) => (
            <FormItem><FormLabel>Email</FormLabel><FormControl><Input placeholder="name@email.com" {...field} /></FormControl><FormMessage /></FormItem>
          )} />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <FormField control={form.control} name="gender" render={({ field }) => (
            <FormItem><FormLabel>Gender</FormLabel>
              <Select onValueChange={field.onChange} value={field.value}>
                <FormControl><SelectTrigger><SelectValue placeholder="Select" /></SelectTrigger></FormControl>
                <SelectContent><SelectItem value="FEMALE">Female</SelectItem><SelectItem value="MALE">Male</SelectItem><SelectItem value="OTHER">Other</SelectItem></SelectContent>
              </Select><FormMessage /></FormItem>
          )} />
          <FormField control={form.control} name="status" render={({ field }) => (
            <FormItem><FormLabel>Status</FormLabel>
              <Select onValueChange={field.onChange} value={field.value}>
                <FormControl><SelectTrigger><SelectValue /></SelectTrigger></FormControl>
                <SelectContent><SelectItem value="NEW">New</SelectItem><SelectItem value="ACTIVE">Active</SelectItem><SelectItem value="INACTIVE">Inactive</SelectItem></SelectContent>
              </Select><FormMessage /></FormItem>
          )} />
        </div>
        <FormItem><FormLabel>Tags</FormLabel>
          <Input placeholder="Botox, VIP" value={tagsText} onChange={(e) => setTagsText(e.target.value)} />
        </FormItem>
        <FormField control={form.control} name="notes" render={({ field }) => (
          <FormItem><FormLabel>Notes</FormLabel><FormControl><Textarea placeholder="Allergies, preferences…" {...field} /></FormControl><FormMessage /></FormItem>
        )} />
        <div className="flex justify-end gap-2">
          <Button type="button" variant="outline" onClick={onDone}>Cancel</Button>
          <Button type="submit" disabled={pending}>{pending ? "Saving…" : defaults?.id ? "Save changes" : "Add patient"}</Button>
        </div>
      </form>
    </Form>
  );
}
