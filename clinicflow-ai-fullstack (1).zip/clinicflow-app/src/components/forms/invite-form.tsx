"use client";
import * as React from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { Mail } from "lucide-react";
import { inviteSchema, type InviteInput } from "@/lib/validations/team";
import { inviteMember } from "@/server/actions/team";
import { Form, FormField, FormItem, FormLabel, FormControl, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select";

export function InviteForm({ onDone }: { onDone?: () => void }) {
  const router = useRouter();
  const [pending, setPending] = React.useState(false);
  const form = useForm<InviteInput>({
    resolver: zodResolver(inviteSchema),
    defaultValues: { name: "", email: "", role: "RECEPTIONIST" },
  });
  async function onSubmit(values: InviteInput) {
    setPending(true);
    const res = await inviteMember(values);
    setPending(false);
    if (res.ok) { toast.success("Invitation sent"); router.refresh(); onDone?.(); }
    else if (res.fieldErrors) Object.entries(res.fieldErrors).forEach(([k, v]) => form.setError(k as any, { message: v?.[0] }));
    else toast.error(res.error ?? "Could not send invite");
  }
  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <FormField control={form.control} name="name" render={({ field }) => (
          <FormItem><FormLabel>Name (optional)</FormLabel><FormControl><Input placeholder="Nurse Bagus" {...field} /></FormControl><FormMessage /></FormItem>
        )} />
        <FormField control={form.control} name="email" render={({ field }) => (
          <FormItem><FormLabel>Email</FormLabel>
            <FormControl><div className="relative"><Mail className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" /><Input placeholder="name@clinic.id" className="pl-9" {...field} /></div></FormControl><FormMessage /></FormItem>
        )} />
        <FormField control={form.control} name="role" render={({ field }) => (
          <FormItem><FormLabel>Role</FormLabel>
            <Select onValueChange={field.onChange} value={field.value}>
              <FormControl><SelectTrigger><SelectValue /></SelectTrigger></FormControl>
              <SelectContent>
                <SelectItem value="MANAGER">Manager</SelectItem><SelectItem value="DOCTOR">Doctor</SelectItem>
                <SelectItem value="RECEPTIONIST">Receptionist</SelectItem><SelectItem value="STAFF">Staff</SelectItem>
              </SelectContent>
            </Select><FormMessage /></FormItem>
        )} />
        <div className="flex justify-end gap-2">
          <Button type="button" variant="outline" onClick={onDone}>Cancel</Button>
          <Button type="submit" disabled={pending}>{pending ? "Sending…" : "Send invite"}</Button>
        </div>
      </form>
    </Form>
  );
}
