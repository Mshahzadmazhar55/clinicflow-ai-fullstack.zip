"use client";
import * as React from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { appointmentSchema, type AppointmentInput } from "@/lib/validations/appointment";
import { createAppointment } from "@/server/actions/appointments";
import { Form, FormField, FormItem, FormLabel, FormControl, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select";

type Opt = { id: string; label: string };
export function AppointmentForm({ patients, services, practitioners, onDone }: {
  patients: Opt[]; services: Opt[]; practitioners: Opt[]; onDone?: () => void;
}) {
  const router = useRouter();
  const [pending, setPending] = React.useState(false);
  const form = useForm<AppointmentInput>({
    resolver: zodResolver(appointmentSchema),
    defaultValues: { patientId: "", serviceId: "", practitionerId: "", startAt: "", durationMin: 30, status: "CONFIRMED", notes: "" },
  });
  async function onSubmit(values: AppointmentInput) {
    setPending(true);
    const res = await createAppointment(values);
    setPending(false);
    if (res.ok) { toast.success("Appointment booked"); router.refresh(); onDone?.(); }
    else if (res.fieldErrors) Object.entries(res.fieldErrors).forEach(([k, v]) => form.setError(k as any, { message: v?.[0] }));
    else toast.error(res.error ?? "Could not book appointment");
  }
  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <FormField control={form.control} name="patientId" render={({ field }) => (
          <FormItem><FormLabel>Patient</FormLabel>
            <Select onValueChange={field.onChange} value={field.value}>
              <FormControl><SelectTrigger><SelectValue placeholder="Select patient" /></SelectTrigger></FormControl>
              <SelectContent>{patients.map((p) => <SelectItem key={p.id} value={p.id}>{p.label}</SelectItem>)}</SelectContent>
            </Select><FormMessage /></FormItem>
        )} />
        <div className="grid grid-cols-2 gap-3">
          <FormField control={form.control} name="serviceId" render={({ field }) => (
            <FormItem><FormLabel>Service</FormLabel>
              <Select onValueChange={field.onChange} value={field.value}>
                <FormControl><SelectTrigger><SelectValue placeholder="Optional" /></SelectTrigger></FormControl>
                <SelectContent>{services.map((s) => <SelectItem key={s.id} value={s.id}>{s.label}</SelectItem>)}</SelectContent>
              </Select><FormMessage /></FormItem>
          )} />
          <FormField control={form.control} name="practitionerId" render={({ field }) => (
            <FormItem><FormLabel>Practitioner</FormLabel>
              <Select onValueChange={field.onChange} value={field.value}>
                <FormControl><SelectTrigger><SelectValue placeholder="Optional" /></SelectTrigger></FormControl>
                <SelectContent>{practitioners.map((p) => <SelectItem key={p.id} value={p.id}>{p.label}</SelectItem>)}</SelectContent>
              </Select><FormMessage /></FormItem>
          )} />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <FormField control={form.control} name="startAt" render={({ field }) => (
            <FormItem><FormLabel>Start</FormLabel><FormControl><Input type="datetime-local" {...field} /></FormControl><FormMessage /></FormItem>
          )} />
          <FormField control={form.control} name="durationMin" render={({ field }) => (
            <FormItem><FormLabel>Duration (min)</FormLabel><FormControl><Input type="number" {...field} /></FormControl><FormMessage /></FormItem>
          )} />
        </div>
        <FormField control={form.control} name="notes" render={({ field }) => (
          <FormItem><FormLabel>Notes</FormLabel><FormControl><Textarea {...field} /></FormControl><FormMessage /></FormItem>
        )} />
        <div className="flex justify-end gap-2">
          <Button type="button" variant="outline" onClick={onDone}>Cancel</Button>
          <Button type="submit" disabled={pending}>{pending ? "Booking…" : "Book appointment"}</Button>
        </div>
      </form>
    </Form>
  );
}
