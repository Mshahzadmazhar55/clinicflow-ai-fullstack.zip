"use client";
import * as React from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { campaignSchema, type CampaignInput } from "@/lib/validations/campaign";
import { createCampaign } from "@/server/actions/campaigns";
import { Form, FormField, FormItem, FormLabel, FormControl, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select";

type Opt = { id: string; label: string };
export function CampaignForm({ segments, onDone }: { segments: Opt[]; onDone?: () => void }) {
  const router = useRouter();
  const [pending, setPending] = React.useState(false);
  const form = useForm<CampaignInput>({
    resolver: zodResolver(campaignSchema),
    defaultValues: { name: "", channel: "WHATSAPP", segmentId: "", body: "", status: "DRAFT", scheduledAt: "" },
  });
  async function onSubmit(values: CampaignInput) {
    setPending(true);
    const res = await createCampaign(values);
    setPending(false);
    if (res.ok) { toast.success("Campaign created"); router.refresh(); onDone?.(); }
    else if (res.fieldErrors) Object.entries(res.fieldErrors).forEach(([k, v]) => form.setError(k as any, { message: v?.[0] }));
    else toast.error(res.error ?? "Could not create campaign");
  }
  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <FormField control={form.control} name="name" render={({ field }) => (
          <FormItem><FormLabel>Campaign name</FormLabel><FormControl><Input placeholder="June Glow Promo" {...field} /></FormControl><FormMessage /></FormItem>
        )} />
        <div className="grid grid-cols-2 gap-3">
          <FormField control={form.control} name="channel" render={({ field }) => (
            <FormItem><FormLabel>Channel</FormLabel>
              <Select onValueChange={field.onChange} value={field.value}>
                <FormControl><SelectTrigger><SelectValue /></SelectTrigger></FormControl>
                <SelectContent><SelectItem value="WHATSAPP">WhatsApp</SelectItem><SelectItem value="EMAIL">Email</SelectItem></SelectContent>
              </Select><FormMessage /></FormItem>
          )} />
          <FormField control={form.control} name="segmentId" render={({ field }) => (
            <FormItem><FormLabel>Segment</FormLabel>
              <Select onValueChange={field.onChange} value={field.value}>
                <FormControl><SelectTrigger><SelectValue placeholder="All patients" /></SelectTrigger></FormControl>
                <SelectContent>{segments.map((s) => <SelectItem key={s.id} value={s.id}>{s.label}</SelectItem>)}</SelectContent>
              </Select><FormMessage /></FormItem>
          )} />
        </div>
        <FormField control={form.control} name="body" render={({ field }) => (
          <FormItem><FormLabel>Message</FormLabel><FormControl><Textarea rows={4} placeholder="Halo Kak! Promo Juni…" {...field} /></FormControl><FormMessage /></FormItem>
        )} />
        <FormField control={form.control} name="scheduledAt" render={({ field }) => (
          <FormItem><FormLabel>Schedule (optional)</FormLabel><FormControl><Input type="datetime-local" {...field} /></FormControl><FormMessage /></FormItem>
        )} />
        <div className="flex justify-end gap-2">
          <Button type="button" variant="outline" onClick={onDone}>Cancel</Button>
          <Button type="submit" disabled={pending}>{pending ? "Saving…" : "Create campaign"}</Button>
        </div>
      </form>
    </Form>
  );
}
