"use client";
import * as React from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { invoiceSchema, type InvoiceInput } from "@/lib/validations/invoice";
import { createInvoice } from "@/server/actions/invoices";
import { Form, FormField, FormItem, FormLabel, FormControl, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select";

type Opt = { id: string; label: string };
export function InvoiceForm({ patients, onDone }: { patients: Opt[]; onDone?: () => void }) {
  const router = useRouter();
  const [pending, setPending] = React.useState(false);
  const form = useForm<InvoiceInput>({
    resolver: zodResolver(invoiceSchema),
    defaultValues: { patientId: "", amount: 0, status: "DRAFT", method: "" },
  });
  async function onSubmit(values: InvoiceInput) {
    setPending(true);
    const res = await createInvoice(values);
    setPending(false);
    if (res.ok) { toast.success("Invoice created"); router.refresh(); onDone?.(); }
    else if (res.fieldErrors) Object.entries(res.fieldErrors).forEach(([k, v]) => form.setError(k as any, { message: v?.[0] }));
    else toast.error(res.error ?? "Could not create invoice");
  }
  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <FormField control={form.control} name="patientId" render={({ field }) => (
          <FormItem><FormLabel>Patient</FormLabel>
            <Select onValueChange={field.onChange} value={field.value}>
              <FormControl><SelectTrigger><SelectValue placeholder="Select patient" /></SelectTrigger></FormControl>
              <SelectContent>{patients.map((p) => <SelectItem key={p.id} value={p.id}>{p.label}</SelectItem>)}</SelectContent>
            </Select><FormMessage /></FormItem>
        )} />
        <div className="grid grid-cols-2 gap-3">
          <FormField control={form.control} name="amount" render={({ field }) => (
            <FormItem><FormLabel>Amount (IDR)</FormLabel><FormControl><Input type="number" {...field} /></FormControl><FormMessage /></FormItem>
          )} />
          <FormField control={form.control} name="status" render={({ field }) => (
            <FormItem><FormLabel>Status</FormLabel>
              <Select onValueChange={field.onChange} value={field.value}>
                <FormControl><SelectTrigger><SelectValue /></SelectTrigger></FormControl>
                <SelectContent>
                  <SelectItem value="DRAFT">Draft</SelectItem><SelectItem value="SENT">Sent</SelectItem>
                  <SelectItem value="PAID">Paid</SelectItem><SelectItem value="OVERDUE">Overdue</SelectItem>
                </SelectContent>
              </Select><FormMessage /></FormItem>
          )} />
        </div>
        <FormField control={form.control} name="method" render={({ field }) => (
          <FormItem><FormLabel>Payment method</FormLabel><FormControl><Input placeholder="QRIS, Card, Transfer…" {...field} /></FormControl><FormMessage /></FormItem>
        )} />
        <div className="flex justify-end gap-2">
          <Button type="button" variant="outline" onClick={onDone}>Cancel</Button>
          <Button type="submit" disabled={pending}>{pending ? "Saving…" : "Create invoice"}</Button>
        </div>
      </form>
    </Form>
  );
}
