"use client";
import * as React from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { leadSchema, type LeadInput } from "@/lib/validations/lead";
import { createLead } from "@/server/actions/leads";
import { Form, FormField, FormItem, FormLabel, FormControl, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select";

export function LeadForm({ onDone }: { onDone?: () => void }) {
  const router = useRouter();
  const [pending, setPending] = React.useState(false);
  const form = useForm<LeadInput>({
    resolver: zodResolver(leadSchema),
    defaultValues: { name: "", phone: "", source: "WHATSAPP", interest: "", value: 0, stage: "NEW" },
  });
  async function onSubmit(values: LeadInput) {
    setPending(true);
    const res = await createLead(values);
    setPending(false);
    if (res.ok) { toast.success("Lead added"); router.refresh(); onDone?.(); }
    else if (res.fieldErrors) Object.entries(res.fieldErrors).forEach(([k, v]) => form.setError(k as any, { message: v?.[0] }));
    else toast.error(res.error ?? "Something went wrong");
  }
  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <FormField control={form.control} name="name" render={({ field }) => (
          <FormItem><FormLabel>Name</FormLabel><FormControl><Input placeholder="Budi Santoso" {...field} /></FormControl><FormMessage /></FormItem>
        )} />
        <div className="grid grid-cols-2 gap-3">
          <FormField control={form.control} name="phone" render={({ field }) => (
            <FormItem><FormLabel>Phone</FormLabel><FormControl><Input placeholder="+62 856…" {...field} /></FormControl><FormMessage /></FormItem>
          )} />
          <FormField control={form.control} name="source" render={({ field }) => (
            <FormItem><FormLabel>Source</FormLabel>
              <Select onValueChange={field.onChange} value={field.value}>
                <FormControl><SelectTrigger><SelectValue /></SelectTrigger></FormControl>
                <SelectContent>
                  <SelectItem value="WHATSAPP">WhatsApp</SelectItem><SelectItem value="INSTAGRAM">Instagram</SelectItem>
                  <SelectItem value="WEBSITE">Website</SelectItem><SelectItem value="GOOGLE">Google</SelectItem>
                  <SelectItem value="TIKTOK">TikTok</SelectItem><SelectItem value="REFERRAL">Referral</SelectItem><SelectItem value="WALK_IN">Walk-in</SelectItem>
                </SelectContent>
              </Select><FormMessage /></FormItem>
          )} />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <FormField control={form.control} name="interest" render={({ field }) => (
            <FormItem><FormLabel>Interest</FormLabel><FormControl><Input placeholder="HydraFacial" {...field} /></FormControl><FormMessage /></FormItem>
          )} />
          <FormField control={form.control} name="value" render={({ field }) => (
            <FormItem><FormLabel>Est. value (IDR)</FormLabel><FormControl><Input type="number" {...field} /></FormControl><FormMessage /></FormItem>
          )} />
        </div>
        <div className="flex justify-end gap-2">
          <Button type="button" variant="outline" onClick={onDone}>Cancel</Button>
          <Button type="submit" disabled={pending}>{pending ? "Saving…" : "Add lead"}</Button>
        </div>
      </form>
    </Form>
  );
}
