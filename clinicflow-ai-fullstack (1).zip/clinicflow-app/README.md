# ClinicFlow AI — Full-Stack SaaS

Multi-tenant clinic OS for beauty, dental, aesthetic & skincare clinics in Indonesia.
WhatsApp AI receptionist, bookings, patient records, CRM, marketing, billing & analytics.

**Stack:** Next.js 14 (App Router) · TypeScript · Prisma · SQLite (dev) / PostgreSQL (prod) ·
NextAuth · Tailwind + shadcn/ui · Zod · React Hook Form · Recharts.

## Quick start

```bash
npm install
npm run db:push      # create the database from the Prisma schema
npm run db:seed      # load a demo clinic + users + patients + everything
npm run dev          # http://localhost:3000
```

Open http://localhost:3000 — it redirects to the dashboard with seeded live data.
Sign-in (optional, /login): **admin@glow-demo.id** / **password123**.

> The app works without any external API keys. OpenAI, WhatsApp (Meta) and Stripe
> are wired and activate automatically when their env vars are set.

## How it's built

**Data layer** — `prisma/schema.prisma` (15 models, row-level `clinicId` isolation),
`src/lib/db.ts` (client singleton), `prisma/seed.ts`.

**Tenancy & auth** — `src/lib/auth.ts` (NextAuth credentials + JWT, role in token),
`src/lib/tenant.ts` (`getCurrentUser` / `getClinicId` / `audit`), `src/middleware.ts`.
Every query and mutation is scoped to the acting user's clinic.

**Validation** — `src/lib/validations/*` — one Zod schema per entity, shared by forms,
server actions, and REST routes.

**Reads** — `src/server/queries.ts` — tenant-scoped queries with pagination, filtering
and chart aggregation.

**Writes (CRUD)** — `src/server/actions/*` — `"use server"` actions for patients, leads,
appointments, campaigns, invoices, team and settings. Each validates input, enforces
RBAC where relevant, writes, logs to the audit trail, and revalidates the page.

**REST API** — `src/app/api/*` mirrors the actions (`/api/patients`, `/api/leads`,
`/api/appointments`, `/api/campaigns`, `/api/invoices`, each with `[id]` handlers),
plus `/api/auth/[...nextauth]`, `/api/webhooks/whatsapp`, `/api/webhooks/stripe`.

**Forms** — `src/components/forms/*` — React Hook Form + Zod resolver + the server
actions, with inline field errors and toasts.

**UI** — 10 pages under `src/app/(app)/*`, all reading live data:
dashboard, calendar, patients, crm, inbox, marketing, analytics, billing, team, settings.
Dark/light mode, charts, tables, search, filters, pagination, empty/loading/error states.

## Production (PostgreSQL)

1. In `prisma/schema.prisma` set `provider = "postgresql"`.
2. Set `DATABASE_URL` to your Postgres (Neon/Supabase) connection string.
3. `npx prisma migrate deploy` instead of `db push`.
4. Set `NEXTAUTH_SECRET`, and the optional `OPENAI_API_KEY`, `WHATSAPP_VERIFY_TOKEN`,
   `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET`.
5. Deploy to Vercel — `build` already runs `prisma generate && next build`.

The row-level `clinicId` model is identical on both databases; no app code changes.

## API examples

```bash
# list patients (paginated, filtered)
curl "http://localhost:3000/api/patients?q=rina&status=active&page=1"

# create a patient
curl -X POST http://localhost:3000/api/patients \
  -H 'Content-Type: application/json' \
  -d '{"fullName":"Sari Dewi","phone":"+62812000111","status":"NEW","tags":["Botox"]}'

# move a lead stage
curl -X PATCH http://localhost:3000/api/leads/LEAD_ID -d '{"stage":"QUALIFIED"}'
```
